# SOURCE REFERENCE: https://github.com/mvillarrealb/docker-spark-cluster/tree/master/docker/spark-master

#!/bin/bash
# startup script to be used in the spark-master container

# Start ssh service for hadoop networking
service ssh start

# Starting Hadoop HDFS
if [ "`ls -A $NAMENODE_STORAGE_DIR`" == "" ]; then
  echo "Formatting namenode name directory: '$NAMENODE_STORAGE_DIR'"
  $HADOOP_HOME/bin/hdfs namenode -format # format namenode
fi

$HADOOP_HOME/sbin/start-dfs.sh
$HADOOP_HOME/sbin/start-yarn.sh
$HADOOP_HOME/bin/mapred --daemon start historyserver

export SPARK_MASTER_HOST=`hostname`
# Extra configurations for "Hadoop Free" build for Spark
# Please see https://spark.apache.org/docs/2.4.4/hadoop-provided.html
# And explanation in https://stackoverflow.com/questions/39943628/the-difference-between-a-hadoop-installed-by-standalone-and-a-hadoop-included-in
export SPARK_DIST_CLASSPATH=$($HADOOP_HOME/bin/hadoop classpath)

. "$SPARK_HOME/sbin/spark-config.sh"
. "$SPARK_HOME/bin/load-spark-env.sh"

mkdir -p $SPARK_MASTER_LOG

ln -sf /dev/stdout $SPARK_MASTER_LOG/spark-master.out

$SPARK_HOME/bin/spark-class \
    org.apache.spark.deploy.master.Master \
    --ip $SPARK_MASTER_HOST --port $SPARK_MASTER_PORT \
    --webui-port $SPARK_MASTER_WEBUI_PORT \
>> $SPARK_MASTER_LOG/spark-master.out
