#!/bin/bash

set -e

echo "Loading env vars from .env to construct 'base' image:"
source .env # load configs from .env file

echo "JAVA_VERSION: ${JAVA_VERSION}"
echo "SPARK_VERSION: ${SPARK_VERSION}"
echo "HADOOP_VERSION: ${HADOOP_VERSION}"
echo "PY_VERSION: ${PY_VERSION}"

# EX: 2.4.4-hadoop2.7
BASE_IMAGE_VERSION=${SPARK_VERSION}-hadoop${HADOOP_VERSION}
echo "Setting BASE_IMAGE_VERSION to: ${BASE_IMAGE_VERSION}\n"

docker build -t base:${BASE_IMAGE_VERSION} \
    --build-arg SPARK_VERSION=${SPARK_VERSION} \
    --build-arg HADOOP_VERSION=${HADOOP_VERSION} \
    --build-arg JAVA_VERSION=${JAVA_VERSION} \
    --build-arg PY_VERSION=${PY_VERSION} \
    -f docker/base/Dockerfile \
    ./
docker build -t hadoop-config:${BASE_IMAGE_VERSION} \
    --build-arg BASE_IMAGE_VERSION=${BASE_IMAGE_VERSION} \
    -f docker/hadoop-config/Dockerfile \
    ./
docker build -t hdfs-upload:${BASE_IMAGE_VERSION} \
    --build-arg BASE_IMAGE_VERSION=${BASE_IMAGE_VERSION} \
    -f docker/hdfs-upload/Dockerfile \
    ./
docker build -t spark-master:${BASE_IMAGE_VERSION} \
    --build-arg BASE_IMAGE_VERSION=${BASE_IMAGE_VERSION} \
    -f docker/spark-master/Dockerfile \
    ./
docker build -t spark-worker:${BASE_IMAGE_VERSION} \
    --build-arg BASE_IMAGE_VERSION=${BASE_IMAGE_VERSION} \
    -f docker/spark-worker/Dockerfile \
    ./
