"""Module contains helper functions for setup.py file
"""
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List


def get_requirements(path: str, sep: str = "#tag:", excluded_subpackages: List[str] = None) -> Dict[str, List[str]]:
    """Helper function to create the list of dependencies requirements for installing zendikon package.
    Using this list and extras_require option in the setuptool, people can install dependencies of the features
    that they are interested in using instead of the whole zendikon package, using zendikon[sub_area], for example,
    zendikon[nlp], zendikon[aml].

    Taking idea from here:
    https://hanxiao.io/2019/11/07/A-Better-Practice-for-Managing-extras-require-Dependencies-in-Python/

    Args:
        path (str): Path to the inverted-index dependencies list.
        excluded_subpackages (List[str]): The list of subpackages to be excluded.
    Returns:
        [Dict[str, List[str]]]: A dictionary contains the list of zendikon packages and their dependencies.
    """
    if sep is None or len(sep.strip()) == 0:
        raise ValueError("Seperator cannot be None or empty string.")

    if excluded_subpackages is None:
        excluded_subpackages = []

    with open(path) as req_file:
        zendikon_dependencies = defaultdict(list)
        all_packages = []
        for line in req_file:
            line = line.strip()

            # The symbol # is for comment in the requirements file
            if line and not line.startswith("#"):
                zendikon_packages = []

                if sep not in line:
                    raise ValueError(f"This line does not contain the separator: {line}")

                package, zendikon_packages_str = [x.strip() for x in line.split(sep)]

                zendikon_packages += [dep.strip() for dep in zendikon_packages_str.split(",")]

                for name in zendikon_packages:
                    if name not in excluded_subpackages:
                        zendikon_dependencies[name].append(package)
                        if package not in all_packages:
                            all_packages.append(package)

        zendikon_dependencies["all"] = all_packages

    return zendikon_dependencies


def get_version(path: str) -> str:
    """Helper method to extract the version information of Zendikon from the zendikon/_version.py file.
    This method will be used in setup.py file, therefore, we cannot directly import the version information
    such as zendikon.VERSION, because zendikon is not available at that time.

    Args:
        path (str): Path to the _version.py file

    Returns:
        str: the current version of Zendikon to be built.
    """
    version_file_path = Path(path)

    if not version_file_path.exists():
        raise ValueError(f"Invalid path to version file path: {path}")

    with open(version_file_path, 'r') as version_file:
        build_version = re.search(r'^VERSION\s*=\s*[\'"]([^\'"]*)[\'"]',  # type: ignore
                                  version_file.read(), re.MULTILINE).group(1)

    return build_version
