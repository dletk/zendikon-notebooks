"""Module contain the implementation of Zendikon AML decorator for FileDataset.
"""
import argparse
import os
import tempfile
import uuid
from functools import wraps
from typing import Any, Callable, List, Optional, Sequence, Tuple

from azureml.core.dataset import Dataset
from azureml.data.file_dataset import FileDataset
from azureml.dataprep.fuse.daemon import MountContext
from typeguard import typechecked
from zendikon.aml.exceptions import ZendikonUserError
from zendikon.aml.step_decorator import (AbstractAmlPythonStepCompatible,
                                         LoadInputType, RegisterOutputType)
from zendikon.aml.types import StepArgument
from zendikon.aml.utils import validate_dataset_names


class FileDataAmlPythonStepCompatible(AbstractAmlPythonStepCompatible):
    """Class represent a Decorator to make a python function working with file data
    become a Python Script step. The path to the parent folder of each input dataset
    will be provided to decorated functions, in the order specified in the function signature,
    unless a method on how to parse the file list is provided.

    The decorated function should return a list of paths to output data directories
    to register to datastore. Each DIRECTORY will be registered as a dataset.::

        def function_name(<input_data1>: str, <input_data2>: str, ....,
                          cli_args: argsparse.Namespace = None,
                          run: aml.core.run = None) -> List[str].
            cli_args: the Namespace from argument parser contain all CLI arguments
            run: the Run instance if this step is run on AML

    """

    @typechecked
    def __init__(  # pylint: disable=too-many-arguments
        self, step_arguments: List[StepArgument] = None,
        as_download: bool = False,
        load_inputs_func: LoadInputType = None,
        register_outputs_func: RegisterOutputType = None
    ) -> None:

        super().__init__(step_arguments=step_arguments,
                         load_inputs_func=load_inputs_func,
                         register_outputs_func=register_outputs_func)

        self.as_download: bool = as_download

        self.mount_context_lst: List[MountContext] = []

        self.temp_download_dir: str = None
        if self.as_download:
            self.temp_download_dir = tempfile.mkdtemp()

    @typechecked
    def __call__(self, function: Callable) -> Callable:
        main_func = super().__call__(function)

        @wraps(function)
        def wrapped(*args, **kwargs):
            # Does not change anything of the base __call__
            result = main_func(*args, **kwargs)

            for mount_context in self.mount_context_lst:
                mount_context.stop()

            return result
        return wrapped

    @typechecked
    def _parse_datasets_to_step_input(self,
                                      input_datasets: List[FileDataset], cli_args: argparse.Namespace
                                      ) -> List[str]:
        """Method to convert a dataset to the correct input for the decorated function in pipeline step.
        This implementation is specific to FileDataset.

        Args:
            input_datasets (List[FileDataset]): The list of input FileDataset for this pipeline step.
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[str]: A list containing path to root directory of each FileDataset.
                A FileDataset may contain multiple files inside this root directory.
        """

        data_file_path = []

        for dataset in input_datasets:
            file_path, mount_context = self.parse_dataset_to_step_input(
                self.as_download, dataset, cli_args, self.temp_download_dir)
            self.mount_context_lst += mount_context
            data_file_path.append(file_path)

        return data_file_path

    @typechecked
    def _register_output_as_dataset(self, outputs: Optional[Sequence[str]],
                                    output_datasets: List[str],
                                    datastore: Any,
                                    cli_args: argparse.Namespace
                                    ) -> List[FileDataset]:
        """The default method used to register the output of this step to datasets. If this is not the desired method,
        user should provide the decorator with their own registering method. That method should have similar signature
        to the default one that they are replacing.

        Args:
            outputs (Optional[List[str]]): List of paths to output data directories to register to datastore.
                Each directory will be registered as a dataset.
            output_datasets (List[str]): Names of datasets to register these output data.
            datastore (Any): The Datastore instance from AML Workspace
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[FileDataset]: List of registered FileDataset reference
        """

        registered_datasets = []
        if outputs is None:
            return registered_datasets

        validate_dataset_names(output_datasets)

        num_output_datasets = len(output_datasets)
        num_outputs = len(outputs)
        if num_output_datasets != num_outputs:
            raise ZendikonUserError(
                f"Number of expected output_datasets is different with number of returned outputs \n \
                Expected: {num_output_datasets}, Actual: {num_outputs}."
            )

        for ds_name, directory_output_path in zip(output_datasets, outputs):
            if os.path.isdir(directory_output_path):
                temp_dataset = self.register_file_path_to_dataset(directory_output_path,
                                                                  ds_name,
                                                                  self.OUTPUT_PATH_PREFIX,
                                                                  self.aml_ws,
                                                                  datastore,
                                                                  cli_args)
                registered_datasets.append(temp_dataset)

        return registered_datasets

    @staticmethod
    @typechecked
    def parse_dataset_to_step_input(as_download: bool,
                                    dataset: FileDataset,
                                    cli_args: argparse.Namespace,  # pylint: disable=unused-argument
                                    download_dir: Optional[str] = None) -> Tuple[str, List[MountContext]]:
        """Method to convert a dataset to the correct input for the decorated function in pipeline step.
        This implementation is specific to FileDataset.

        Args:
            as_download (bool): Whether to download the dataset or mount from elsewhere
            dataset (FileDataset): The input FileDataset for this pipeline step.
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.
            download_dir (Optional[str]): If as_download, the temp dir to download into

        Returns:
            Tuple[str, List[MountContext]]: A tuple containing:
                - A path to root directory of the FileDataset, which may contain multiple files.
                - A list of mount contexts recorded to unmount later
        """
        if as_download:  # pylint: disable=no-else-return
            if download_dir is None:
                raise ValueError("download_dir cannot be None if as_download is True")

            temp_dir = os.path.join(download_dir, dataset.name)
            os.makedirs(temp_dir)
            dataset.download(target_path=temp_dir)
            return (temp_dir, [])
        else:
            mount_context_lst = []
            mount_context = dataset.mount()
            mount_context.start()

            # Record the mount context to unmount later
            mount_context_lst.append(mount_context)

            mount_point = mount_context.mount_point
            return (mount_point, mount_context_lst)

    @staticmethod
    @typechecked
    def register_file_path_to_dataset(directory_output_path: str,  # pylint: disable=too-many-arguments
                                      ds_name: str,
                                      output_path_prefix: str,
                                      aml_ws: Any,
                                      datastore: Any,
                                      cli_args: argparse.Namespace) -> FileDataset:   # pylint: disable=unused-argument
        """The method to register a given file path as a dataset on given AML workspace.

        Args:
            directory_output_path (str): Directory containing the output file
            ds_name (str): Name of the dataset to register the file for
            output_path_prefix (str): Prefix to the output file path
            aml_ws_datastore (Tuple[Any, Any]): The current AML workspace and datastore to register the file to
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            FileDataset: The resulting FileDataset after registered on AML
        """
        temp_uuid = str(uuid.uuid4())
        temp_dataset = Dataset.File.upload_directory(
            directory_output_path, (datastore, output_path_prefix+ds_name+f"/{temp_uuid}"))
        temp_dataset.register(aml_ws, ds_name, create_new_version=True)
        return temp_dataset
