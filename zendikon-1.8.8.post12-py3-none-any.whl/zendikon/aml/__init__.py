"""Module containing components to support AML pipeline structure.
"""
