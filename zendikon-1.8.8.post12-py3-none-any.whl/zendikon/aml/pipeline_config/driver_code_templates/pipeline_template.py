
# In[1]:
import os
import sys

import azureml.core

from azureml.pipeline.core import PipelineData
from azureml.core import RunConfiguration
from azureml.core.conda_dependencies import CondaDependencies
from azureml.core.compute_target import ComputeTargetException
from azureml.core.compute import ComputeTarget, AmlCompute

from azureml.core import Workspace, ComputeTarget, Experiment
from azureml.pipeline.steps import PythonScriptStep
from azureml.pipeline.core import Pipeline
# check core SDK version number
print("Azure ML SDK Version: ", azureml.core.VERSION)


# In[2]:


# load workspace
workspace = Workspace.from_config()
print('Workspace name: ' + workspace.name,
      'Azure region: ' + workspace.location,
      'Subscription id: ' + workspace.subscription_id,
      'Resource group: ' + workspace.resource_group, sep='\n')


# In[3]:

{% if config.workspace_config.datastore == "default" %}
datastore = workspace.get_default_datastore()
{% else %}
datastore = workspace.datastores["{{config.workspace_config.datastore}}"]
{% endif %}


# In[4]:


# Get compute target and all logistic things done

# create an ML experiment
exp = Experiment(workspace=workspace, name="{{config.experiment_config.name}}")

# create a directory
script_folder = "{{config.pipeline_config.script_folder}}"


# choose a name for your cluster
cluster_name = "{{config.workspace_config.compute_target}}"

try:
    compute_target = ComputeTarget(workspace=workspace, name=cluster_name)
    print('Found existing compute target')
except ComputeTargetException:
    print('Creating a new compute target...')
    compute_config = AmlCompute.provisioning_configuration(vm_size='STANDARD_NC6',
                                                           max_nodes=4)

    # create the cluster
    compute_target = ComputeTarget.create(
        workspace, cluster_name, compute_config)

    # can poll for a minimum number of nodes and for a specific timeout.
    # if no min node count is provided it uses the scale settings for the cluster
    compute_target.wait_for_completion(
        show_output=True, min_node_count=None, timeout_in_minutes=20)

# use get_status() to get a detailed status for the current cluster.
print(compute_target.get_status().serialize())


# # Steps

# In[5]:

# Set the personal access token for the pipeline, later on, this should be something we provided via our CLI
pat_token = sys.argv[1]
workspace.set_connection(name="PAT for installing Zendikon",
   category = "PythonFeed",
   target = "https://pkgs.dev.azure.com",
   authType = "PAT",
   value = pat_token)

conda_dependencies = CondaDependencies(conda_dependencies_file_path="{{config.pipeline_config.conda_dependencies}}")
conda_dependencies.set_pip_option("--extra-index-url https://pkgs.dev.azure.com/MAIDAP/Zendikon/_packaging/maidap-zendikon/pypi/simple/")
# Using exact version due to a bug on AML. Implementation of getting the version from config will be added later.
conda_dependencies.add_pip_package("zendikon=={{version}}")

prep_config = RunConfiguration(conda_dependencies=conda_dependencies)


# In[7]:

steps = []

{% for step in config.pipeline_config.step_configs %}
{% for output in step.outputs %}
{{output}} = PipelineData("{{output}}", datastore=datastore)
{% endfor %}

{{step.name}} = PythonScriptStep(name='{{step.name}}',
                                 script_name="{{step.script_path}}",
                                 # mount fashion_ds dataset to the compute_target, prepare_fashion_ds is the output path.
                                 # It is pointing to a datastore
                                 arguments=["--named_input_datasets", "{{step.inputs|join(',')}}",
                                            "--named_output_datasets", "{{step.outputs|join(',')}}", {% for key, val in step.arguments.items() %}"--{{key}}", "{{val}}", {% endfor %}],
                                 {% if step.inputs_from_ancesstors|length > 0 %}
                                 inputs=[{% for input in step.inputs_from_ancesstors %}{{input}},{% endfor %}],
                                 {% endif %}
                                 outputs=[{% for output in step.outputs %}{{output}},{% endfor %}],
                                 source_directory=script_folder,
                                 compute_target=compute_target,
                                 runconfig=prep_config,
                                 allow_reuse=True)

steps.append({{step.name}})
{% endfor %}

# In[10]:

pipeline = Pipeline(workspace, steps=steps)
run = exp.submit(pipeline)
