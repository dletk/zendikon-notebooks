"""Module to implement the code generator to create driver code for AML pipeline
from the YAML config file.
"""
from pathlib import Path

from jinja2 import Environment, FileSystemLoader
from typeguard import typechecked

from zendikon import VERSION
from zendikon.aml.pipeline_config.zendikon_config import ZendikonAmlConfig


_PIPELINE_TEMPLATE_DIR = Path(__file__).parent / "driver_code_templates"
_PIPELINE_TEMPLATE_FILENAME = "pipeline_template.py"


@typechecked
def generate_driver_code(config_file_path: Path, output_file_path: Path,
                         template_dir: Path = _PIPELINE_TEMPLATE_DIR,
                         template_filename: str = _PIPELINE_TEMPLATE_FILENAME) -> None:
    """Function to generate a complete driver code for AML pipeline using the given config yml file
    following Zendikon schema. This function is also exposed as a CLI command.

    Args:
        config_file_path (Path): The path to the Zendikon config yml file.
        output_file_path (Path): The output path to store the generated driver code.
        template_dir (Path, optional): The directory containing the Jinjia2 template for the driver code.
            Defaults to _PIPELINE_TEMPLATE_DIR.
        template_filename (str, optional): The filename of the Jinjia2 template in the template directory.
            Defaults to _PIPELINE_TEMPLATE_FILENAME.

    Raises:
        ValueError: raised if the required files do not exist or the template file name is an empty string.
    """

    if not config_file_path.exists():
        raise ValueError(f"config_path does not exist: {config_file_path}")

    if not template_dir.exists():
        raise ValueError(f"template_dir does not exist: {template_dir}")

    if len(template_filename) == 0:
        raise ValueError("template_filename cannot be an empty string.")
    if template_filename.isspace():
        raise ValueError("template_filename cannot be a whitespace string.")

    aml_config = ZendikonAmlConfig(config_file_path)

    env = Environment(loader=FileSystemLoader(template_dir), lstrip_blocks=True, trim_blocks=True, autoescape=True)
    template = env.get_template(template_filename)

    with open(output_file_path, "w") as output_f:
        parsed_template = template.render(config=aml_config, version=VERSION)
        output_f.write(parsed_template)
