"""Module containing the implementation of AML StepConfig class
"""

import re
from pathlib import Path
from typing import Any, Dict, List, Set

from typeguard import typechecked

from zendikon.aml.utils import validate_dataset_names


class BaseStepConfig():
    """Represents the configuration for an AML Python Script step
    """

    STEP_CONFIG_SCRIPT_PATH_KEY: str = "script"
    STEP_CONFIG_INPUTS_KEY: str = "inputs"
    STEP_CONFIG_OUTPUTS_KEY: str = "outputs"
    STEP_CONFIG_ARGUMENTS_KEY: str = "arguments"

    @typechecked
    def __init__(self, name: str, script_folder: Path, step_config_dict: Dict[str, Any]) -> None:
        """Create a step configuration from a step config dict.

        Args:
            name (str): name for this step in the pipeline.
            script_folder (Path): The root directory to start searching for step .py script.
            step_config_dict (Dict[str, Any]): The step config dict from config yml file.

        Raises:
            ValueError: raised if script path does not exist or invalid step name.
        """

        if bool(re.fullmatch(r"\s*", name)):
            raise ValueError("Step name cannot be an empty string or white spaces only.")

        self.name: str = name

        script_path: Path = Path(step_config_dict[self.STEP_CONFIG_SCRIPT_PATH_KEY])

        # The script path is relative to the script folder path, so we need to combine them
        # for full path before validation.
        if not script_folder.joinpath(script_path).exists():
            raise ValueError(f"The script path does not exist! {script_folder/script_path}")

        #: Script path is in POSIX string format to be compatible with all platforms
        # Using POSIX to avoid \t, \n special character in the path string.
        self.script_path: str = script_path.as_posix()

        # Optional attributes
        # Empty inputs, outputs, or arguments are valid options, the value will be None
        self.inputs: List[str] = step_config_dict.get(self.STEP_CONFIG_INPUTS_KEY, [])
        validate_dataset_names(self.inputs)

        self.outputs: List[str] = step_config_dict.get(self.STEP_CONFIG_OUTPUTS_KEY, [])
        validate_dataset_names(self.outputs)

        self.arguments: Dict[str, Any] = step_config_dict.get(self.STEP_CONFIG_ARGUMENTS_KEY, dict())

        # Inputs which are output of other steps
        self.inputs_from_ancesstors: Set[str] = set()
