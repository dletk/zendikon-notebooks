"""Module containing implementation of the AML Pipeline config class
"""
from pathlib import Path
from typing import Any, Dict, List

from typeguard import typechecked

from zendikon.aml.pipeline_config.step_config import BaseStepConfig


class PipelineConfig():
    """Represents the configuration for the AML Pipeline section in Zendikon config file.
    """

    PIPELINE_CONFIG_KEY: str = "pipeline"
    PIPELINE_CONFIG_CONDA_DEP_KEY: str = "conda_dependencies"
    PIPELINE_CONFIG_SCRIPT_FOLDER_KEY: str = "script_folder"
    PIPELINE_CONFIG_STEPS_KEY: str = "steps"

    @typechecked
    def __init__(self, config_dict: Dict[str, Any]) -> None:
        """Create a new instance of Pipeline config from the config dictionary
        that contains parsed information from config YAML file.

        Args:
            config_dict (Dict[str, Any]): The dictionary containing parsed information from config YAML file.

        Raises:
            ValueError: raised when the required paths are not valid or there is no step in the pipeline.
        """

        pipeline_config_dict = config_dict[self.PIPELINE_CONFIG_KEY]

        conda_dependencies_path = Path(pipeline_config_dict[self.PIPELINE_CONFIG_CONDA_DEP_KEY])

        script_folder = Path(pipeline_config_dict[self.PIPELINE_CONFIG_SCRIPT_FOLDER_KEY])

        if not script_folder.exists():
            raise ValueError(f"Script_folder path does not exists. {script_folder}")

        conda_path_from_script_folder = script_folder / conda_dependencies_path
        if not conda_path_from_script_folder.exists():
            raise ValueError(f"Conda dependencies path does not exists, {conda_path_from_script_folder}")

        self.conda_dependencies = conda_dependencies_path.as_posix()

        # List of step config dict
        step_lst: List[Dict[str, Dict]] = pipeline_config_dict[self.PIPELINE_CONFIG_STEPS_KEY]

        if len(step_lst) == 0:
            raise ValueError("There is no step in the pipeline config.")

        self.step_configs: List[BaseStepConfig] = []

        for step in step_lst:
            for step_name, step_dict in step.items():
                self.step_configs.append(BaseStepConfig(step_name, script_folder, step_dict))

        # Convert script folder path as POSIX to work with both Windows and Ubuntu
        self.script_folder = script_folder.as_posix()

        find_intermediate_inputs_between_steps(self.step_configs)


@typechecked
def find_intermediate_inputs_between_steps(step_configs: List[BaseStepConfig]):
    """Helper method to find the intermediate input between all steps in the current config dict.

    Args:
        step_configs (List[StepConfig]): The list of step configs to find dependencies.
    """

    for i, step in enumerate(step_configs):
        if len(step.inputs) == 0:
            continue

        for input_data in step.inputs:
            for previous_step in step_configs[:i]:
                if input_data in previous_step.outputs:
                    step.inputs_from_ancesstors.add(input_data)
