"""Modules containing implementation for the config object to read a config file and create a graph structure
to map the config to an AML pipeline
"""
from pathlib import Path

import yaml
from typeguard import typechecked

from zendikon.aml.pipeline_config.pipeline_config import PipelineConfig
from zendikon.aml.pipeline_config.experiment_config import ExperimentConfig
from zendikon.aml.pipeline_config.workspace_config import WorkspaceConfig


class ZendikonAmlConfig():
    """Class represents the config object to process Zendikon pipeline config file and create an object to represent
    the AML pipeline. This object will later be used to construct the driver code for actual AML pipeline implementaion.
    """

    @typechecked
    def __init__(self, config_file_path: Path) -> None:
        """Create an instance of PipelineConfig with the given config file.

        Args:
            config_file_path (Path): Path to the yml config file.

        Raises:
            ValueError: Raised when the config file path does not exist.
        """
        if not config_file_path.exists():
            raise ValueError(f"config_file_path does not exist: {config_file_path}")

        with open(config_file_path, "r") as config_file:
            self._config_dict = yaml.safe_load(config_file)

        self.workspace_config = WorkspaceConfig(self._config_dict)
        self.experiment_config = ExperimentConfig(self._config_dict)
        self.pipeline_config = PipelineConfig(self._config_dict)
