"""Module contain the implementation of Zendikon AML decorator for both Tabular and File Dataset
"""
import argparse
import os
import tempfile
from enum import Enum
from functools import wraps
from typing import Any, Callable, List, Optional, Sequence, Union

import pandas as pd
from azureml.data.abstract_dataset import AbstractDataset
from azureml.data.file_dataset import FileDataset
from azureml.data.tabular_dataset import TabularDataset
from azureml.dataprep.fuse.daemon import MountContext
from typeguard import typechecked
from zendikon.aml.exceptions import (ZendikonDatasetMismatchError,
                                     ZendikonInternalError, ZendikonUserError)
from zendikon.aml.file_data_step_decorator import \
    FileDataAmlPythonStepCompatible
from zendikon.aml.step_decorator import (AbstractAmlPythonStepCompatible,
                                         LoadInputType, RegisterOutputType)
from zendikon.aml.tabular_data_step_decorator import \
    TabularDataAmlPythonStepCompatible
from zendikon.aml.types import StepArgument
from zendikon.aml.utils import validate_dataset_names


class DatasetType(Enum):
    """Enum class to represent the types of datasets, Tabular or File.
    This is to not depend (at least on user interface level) on AML's TabularDataset and FileDataset.

    """
    TABULAR = 1
    FILE = 2


TABULAR = DatasetType.TABULAR
FILE = DatasetType.FILE


class AmlPipelineStep(AbstractAmlPythonStepCompatible):
    """Class represent a Decorator to make a python function working with file data
    become a Python Script step. The list of paths to data file on AML datastore will be provided
    to decorated functions, unless a method on how to parse the file list is provided.

    The decorated function should return a list of paths to output data directories
    to register to datastore. Each DIRECTORY will be registered as a dataset.::

        def function_name(<input_data1>: List[str], <input_data2>: List[str], ....,
                          cli_args: argsparse.Namespace = None,
                          run: aml.core.run = None) -> List[str].
            cli_args: the Namespace from argument parser contain all CLI arguments
            run: the Run instance if this step is run on AML

    """

    @typechecked
    def __init__(  # pylint: disable=too-many-arguments
        self, input_types: List[DatasetType],
        output_types: List[DatasetType],
        step_arguments: List[StepArgument] = None,
        as_download: bool = False,
        load_inputs_func: LoadInputType = None,
        register_outputs_func: RegisterOutputType = None
    ) -> None:

        super().__init__(step_arguments=step_arguments,
                         load_inputs_func=load_inputs_func,
                         register_outputs_func=register_outputs_func)

        self.input_types: List[DatasetType] = input_types
        self.output_types: List[DatasetType] = output_types

        # For File Dataset handling
        self.as_download: bool = as_download
        self.mount_context_lst: List[MountContext] = []
        self.temp_download_dir: str = None
        if self.as_download:
            self.temp_download_dir = tempfile.mkdtemp()

    @typechecked
    def __call__(self, function: Callable) -> Callable:
        main_func = super().__call__(function)

        @wraps(function)
        def wrapped(*args, **kwargs):
            # Does not change anything of the base __call__
            result = main_func(*args, **kwargs)

            # Unmount, if any
            for mount_context in self.mount_context_lst:
                mount_context.stop()

            return result

        return wrapped

    @typechecked
    def _parse_datasets_to_step_input(self,
                                      input_datasets: List[AbstractDataset], cli_args: argparse.Namespace
                                      ) -> List[Union[str, pd.DataFrame]]:
        """Method to convert a list of dataset to the correct input for the decorated function in pipeline step.
        This implementation is accommodating a mix of File and Tabular Datasets.

        Args:
            input_datasets (List[AbstractDataset]): The list of input dataset for this pipeline step,
                can be either File or Tabular dataset.
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[Union[str, pd.DataFrame]]: A list containing path to root directory of each FileDataset,
                or pandas dataframe for each Tabular Dataset.
                A FileDataset may contain multiple files inside this root directory.
        """
        self.validate_dataset_types(input_datasets, self.input_types)
        input_data = []
        for dataset in input_datasets:
            input_data.append(self._parse_dataset_to_step_input(dataset, cli_args))
        return input_data

    @typechecked
    def _parse_dataset_to_step_input(self,
                                     input_dataset: AbstractDataset,
                                     cli_args: argparse.Namespace
                                     ) -> Union[str, pd.DataFrame]:
        """Method to convert a dataset to the correct input for the decorated function in pipeline step.
        This implementation is for both File and Tabular Dataset.

        Args:
            input_dataset (AbstractDataset): An input dataset, can be either File or Tabular dataset.
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            Union[str, pd.DataFrame]: A path to root directory of the FileDataset,
                or pandas dataframe for the Tabular Dataset.
                A FileDataset may contain multiple files inside this root directory.
        """
        if isinstance(input_dataset, TabularDataset):
            return TabularDataAmlPythonStepCompatible.parse_dataset_to_step_input(input_dataset, cli_args)

        if isinstance(input_dataset, FileDataset):  # pylint: disable=no-else-return
            file_path, mount_context = FileDataAmlPythonStepCompatible. \
                parse_dataset_to_step_input(self.as_download,
                                            input_dataset,
                                            cli_args,
                                            self.temp_download_dir)
            self.mount_context_lst += mount_context
            return file_path

        raise ZendikonInternalError(
            f"Input dataset is neither File or Tabular Dataset. \
            Required to be either File or Tabular. Got: {type(input_dataset)}")

    @typechecked
    def _register_output_as_dataset(self, outputs: Optional[Sequence[Union[str, pd.DataFrame]]],
                                    output_datasets: List[str],
                                    datastore: Any,
                                    cli_args: argparse.Namespace
                                    ) -> List[AbstractDataset]:
        """The default method used to register the output of this step to datasets.
        If this is not the desired method, user should provide the decorator with their own registering method.
        That method should have similar signature to the default one that they are replacing.

        Args:
            outputs (Optional[Sequence[Union[str, pd.DataFrame]]]): List of paths to output data directories to register
                to datastore for FileDataset, or the pandas dataframes to register for TabularDataset.
                Each directory will be registered as a dataset.
            output_datasets (List[str]): Names of datasets to register these output data.
            datastore (Any): The Datastore instance from AML Workspace
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[AbstractDataset]: List of registered FileDataset or TabularDataset reference
        """

        registered_datasets = []

        if outputs is None:
            return registered_datasets

        num_output_datasets = len(output_datasets)
        num_outputs = len(outputs)
        if num_output_datasets != num_outputs:
            raise ZendikonUserError(
                f"Number of expected output_datasets is different with number of returned outputs \n \
                Expected: {num_output_datasets}, Actual: {num_outputs}."
            )

        validate_dataset_names(output_datasets)
        self.validate_data_types(outputs, self.output_types)

        for ds_name, output in zip(output_datasets, outputs):
            if isinstance(output, pd.DataFrame):
                registered_datasets.append(
                    TabularDataAmlPythonStepCompatible.register_dataframe_as_dataset(
                        output, self.OUTPUT_PATH_PREFIX, ds_name, datastore, cli_args)
                )
            elif isinstance(output, str):
                if os.path.isdir(output):
                    registered_datasets.append(
                        FileDataAmlPythonStepCompatible.register_file_path_to_dataset(
                            output, ds_name, self.OUTPUT_PATH_PREFIX,
                            self.aml_ws, datastore, cli_args))
            else:
                raise ZendikonInternalError(
                    "Dataset to register is neither File or Tabular Dataset. Required to be either File or Tabular")

        return registered_datasets

    @staticmethod
    @typechecked
    def validate_dataset_types(source_datasets: Sequence[AbstractDataset], target_types: List[DatasetType]) -> bool:
        """Function to validate whether the list of datasets follow the user-specified types in the decorator signature.
        The datasets' types and target types should map in order.

        Notice: An empty list is a valid option.

        Args:
            source_datasets (Sequence[AbstractDataset]): The list of datasets to validate.
            target_types (List[DatasetType]): The list of user-expected types of the source datasets.

        Raises:
            ZendikonDatasetMismatchError: Raised if one of the dataset in the list does not
             match user's intended types.

        Returns:
            bool: True if all datasets in the list have the expected types.
        """
        for dataset, dataset_type in zip(source_datasets, target_types):

            #pylint: disable=too-many-boolean-expressions
            if (not isinstance(dataset, TabularDataset) and not isinstance(dataset, FileDataset)) or \
                (isinstance(dataset, TabularDataset) and dataset_type != TABULAR) or \
                    (isinstance(dataset, FileDataset) and dataset_type != FILE):
                raise ZendikonDatasetMismatchError(
                    f"Type of expected dataset is different from returned dataset \n \
                        Expected: {dataset_type}, Actual: {type(dataset)}"
                )

        return True

    @staticmethod
    @typechecked
    def validate_data_types(source_data: Sequence[Union[str, pd.DataFrame]], target_types: List[DatasetType]) -> bool:
        """Function to validate whether the list of data follow the user-specified types in the decorator signature.
        The data' types and target types should map in order, str for FileDataset and pandas Dataframe for Tabular.

        Notice: An empty list is a valid option.

        Args:
            source_data (Sequence[Union[str, pd.DataFrame]]]): The list of data to validate.
            target_types (List[DatasetType]): The list of user-expected types of the source data to validate against.

        Raises:
            ZendikonDatasetMismatchError: Raised if one of the dataset in the list does not
             match user's intended types.

        Returns:
            bool: True if all data in the list have the expected types.
        """
        for data, data_type in zip(source_data, target_types):
            if (isinstance(data, pd.DataFrame) and data_type != TABULAR) or \
                    (isinstance(data, str) and data_type != FILE):
                # Denote what data type is expected for Tabular vs. File
                str_type = "pd.DataFrame" if data_type == TABULAR else "str"
                raise ZendikonDatasetMismatchError(
                    f"Type of expected dataset is different from returned data \n \
                        Expected: {str_type}, Actual: {type(data)}"
                )

        return True
