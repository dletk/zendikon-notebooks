"""Module containing helper functions to perform some frequent tasks that are related to pipelines.
"""
import json
from collections import namedtuple
from typing import Dict, Union, List

from azureml.train.automl.run import AutoMLRun
from typeguard import typechecked

from zendikon.pipelines._pipeline_step_info import PipelineStepInfo
from zendikon.utils.utils import get_repeated_elements

RunIdModelName = namedtuple("RunIdModelName", ["run_id", "model_name"])


@typechecked
def validate_steps_info(steps_info: List[PipelineStepInfo]) -> None:
    """Method to validate if the provided steps_info is a valid input.

    Args:
        steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.

    Raises:
        ValueError: If steps_info is an empty list.
        Warning: Print statement if there are input datasets not generated from any step's output
    """
    if steps_info is not None and len(steps_info) == 0:
        raise ValueError("steps_info is an empty list.")

    # Checking if output dataset names are unique across all steps
    all_output_dataset_names = [output_dataset
                                for step_info in steps_info
                                for output_dataset in step_info.step_config.outputs]
    repeated_output_names = get_repeated_elements(all_output_dataset_names)
    if len(repeated_output_names) > 0:
        raise ValueError("Output dataset names {0} are being repeated in the".format(repeated_output_names) +
                         " steps_info list")

    # Observing if there are input datasets not generated as output from any step
    unaccounted_input_ds = _get_unaccounted_input_datasets(steps_info)
    if len(unaccounted_input_ds) > 0:
        print('\nWarning: The following datasets ({0}) are not the output(s)'.format(unaccounted_input_ds) +
              ' of any step in your pipeline and are assumed to be registered in your pipeline workspace.',
              'If this is not your intention, we recommend interrupting the command ' +
              'using Ctrl + c and check your pipeline config.\n', sep='\n')


@typechecked
def _get_unaccounted_input_datasets(steps_info: List[PipelineStepInfo]) -> List[str]:
    """Helper function to get input dataset names which aren't generated from any step's output.

    Args:
        steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.

    Returns:
        List[str]: List of 0 or more names of input datasets not generated from any step's output.
    """
    # Mapping between an output dataset name and the corresponding PipelineStepInfo object
    output_to_psi_map = {output_name: step_info
                         for step_info in steps_info
                         for output_name in step_info.step_config.outputs}

    # List of input datasets not generated from any step's output
    unaccounted_input_ds = [input_name
                            for step_info in steps_info
                            for input_name in step_info.step_config.inputs
                            if input_name not in output_to_psi_map]
    return unaccounted_input_ds


@typechecked
def get_models_and_metrics_from_automl_run(automl_run: AutoMLRun) -> Dict[RunIdModelName, Dict[str, Union[float, str]]]:
    """Helper method to retrieve all models and associated metrics trained by an instance of AutoML run.
    There can be multiple models with the same name but different hyperparameters got run by AutoML, so
    we use the RunID combined with model name as the key for distinguishing between models. The metrics
    returned with the model should allow users to make more complex decision on model selection, and they
    can retrieve the actual model files using the run ID.


    Args:
        automl_run (AutoMLRun): The instance of AutoMLRun to retrieve models info.

    Returns:
        Dict[RunIdModelName, Dict[str, Union[float, str]]]: A dictionary in format the following format:
            {(RunID, model_name): {metric1: 0.5, metric2: 0.7, metric3: 'path/to/metric/file',...}}
    """
    child_runs = automl_run.get_children()

    models_info = {}

    for child in child_runs:
        metrics = child.get_metrics()
        run_id = child.id

        # Note: this is specific to the current structure of the properties from AML. It is hard-coded
        # and should be checked with major release change from AzureML SDK.
        try:
            specs = json.loads(child.get_properties()["pipeline_spec"])
        except KeyError:
            print("=============== ***** ==============")
            print("Cannot find pipeline_spec in this run, may be a set up run. RunID = ", run_id)
            print("=============== ***** ==============")
            continue

        try:
            model_name = _extract_model_name(specs)
            # Notice: There can be multiple models with the same name, but they use different hyperparameters
            # That's why we are using RunId as the key, not model name.
            models_info[RunIdModelName(run_id, model_name)] = {
                **metrics
            }
        except KeyError:
            print("=============== ***** ==============")
            print("This run instance was missing model information, id: ", run_id)
            print("Associated metrics: ", metrics)
            print("=============== ***** ==============")

    return models_info


@typechecked
def _extract_model_name(specs: Dict) -> str:
    """Helper method to extra model name from an AutoMLRun pipeline spec. This pipeline spec dictionary is different for
    different model types (whether it is from sklearn or other sources,...), or whether there is any preprocessing
    step before that. Hence, this method is a bit specific to the current representation we got from AutoML.

    Args:
        specs (Dict): The pipeline spec dictionary obtained from AutoML Run properties.

    Returns:
        str: Name of the model associated with this spec.
    """
    # Example specs:
    # {"objects": [{"class_name": "SamplePreprocessor", "module": "sklearn.preprocessing", "param_args": [],
    # "param_kwargs": {}, "prepared_kwargs": {}, "spec_class": "preproc"}, {"class_name": "SampleModel",
    # "module": "sklearn.linear_model", "param_args": [],
    # "param_kwargs": {"alpha": 0.001, "l1_ratio": 0.8436842105263158, "normalize": false},
    # "prepared_kwargs": {}, "spec_class": "sklearn"}],
    # "pipeline_id": "7839ca66a0ff9be386363c852f0384a7b2a1c93f", "module": "sklearn.pipeline",
    # "class_name": "Pipeline", "pipeline_name": "{ SamplePreprocessor, SampleModel }"}'
    model_names = []

    models_info = specs["objects"]
    for info in models_info:
        model_names.append(info["class_name"])

    return ", ".join(model_names)
