"""Subpackage containing the reusable ML pipelines collection for Time Series Forecasting.
"""

from zendikon.pipelines.time_series.forecasting.pipeline import TimeSeriesForecastingPipeline
