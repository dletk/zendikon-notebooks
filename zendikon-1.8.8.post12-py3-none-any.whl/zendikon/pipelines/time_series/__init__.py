"""Subpackage containing ML pipelines collection working with Time series data.
"""
