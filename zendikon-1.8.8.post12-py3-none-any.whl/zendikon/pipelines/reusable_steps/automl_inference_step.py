"""Module containing the Zendikon AutoML Inference step source code.
"""

from pathlib import Path
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig


class ZendikonAutoMLInferenceStep(BasePipelineStep):
    """Class representing the step for performing inferencing on the AutoML best model
    returned by the ZendikonAutoMLStep instance.
    """

    DEFAULT_SOURCE_DIR = Path(__file__).parent.resolve() / "step_scripts" / "automl_inference_step"

    def __init__(self, step_config: StepConfig) -> None:
        super().__init__(step_config=step_config, source_directory=self.DEFAULT_SOURCE_DIR)
