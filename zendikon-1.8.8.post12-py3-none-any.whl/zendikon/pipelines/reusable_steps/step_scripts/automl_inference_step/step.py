import joblib
import os

from zendikon.aml.mixed_data_step_decorator import FILE, AmlPipelineStep, TABULAR
from zendikon.aml.types import StepArgument


@AmlPipelineStep(input_types=[TABULAR, FILE], output_types=[], step_arguments=[
    StepArgument("target_column", "Name of the target column in the test dataset", str, required=True)
])
def run_step(test_df, model_folder_path, cli_args=None, run=None):
    target_column_name = cli_args.target_column
    print(model_folder_path)
    print(os.listdir(model_folder_path))
    fitted_model = joblib.load(model_folder_path + "/model.pkl")
    print(fitted_model)
    X_test_df = test_df.drop(columns=[target_column_name]).reset_index(drop=True)

    y_test_df = test_df[[target_column_name]]
    # Produce forecasts on a rolling origin over the given test set.
    # Each iteration makes a forecast for the next 'max_horizon' periods with respect to the current origin,
    # then advances the origin by the horizon time duration. The prediction context for each forecast is set
    # so that the forecaster uses the actual target values prior to the current origin time for constructing lag features.
    # This function returns a concatenated DataFrame of rolling forecasts joined with the actuals from the test set.
    y_pred, X_trans = fitted_model.rolling_evaluation(X_test_df, y_test_df.values)

    # Add predictions, actuals, and horizon relative to rolling origin to the test feature data
    assign_dict = {
        "predicted": y_pred,
        target_column_name: y_test_df[target_column_name].values,
    }
    df_all = X_test_df.assign(**assign_dict)

    return [df_all]


if __name__ == "__main__":
    run_step()
