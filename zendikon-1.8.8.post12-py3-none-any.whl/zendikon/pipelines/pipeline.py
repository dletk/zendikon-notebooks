"""Module containing implementation of the Reusable pipeline class and other supporting classes.
"""

from typing import Any, Callable, Dict, List, Sequence, Type

from azureml.core import ComputeTarget, Experiment, Run
from azureml.pipeline.core import Pipeline as AmlPipeline
from azureml.pipeline.core import PipelineStep, PipelineData
from typeguard import typechecked

from zendikon.aml.utils import validate_dataset_names
from zendikon.pipelines._pipeline_step_info import PipelineStepInfo
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig
from zendikon.pipelines.utils import validate_steps_info


class Pipeline:
    """The class represents an ML pipeline created using Zendikon.
    """

    @typechecked
    def __init__(self, input_datasets: Sequence[str],
                 compute_targets: List[ComputeTarget],
                 steps_info: List[PipelineStepInfo],
                 step_factory: Callable[[Type[BasePipelineStep], StepConfig], BasePipelineStep] = None) -> None:
        """Create an instance of pipeline with Zendikon.

        Args:
            input_datasets (Sequence[str]): Names of the input datasets of the pipeline.
                Empty sequence is valid input. It means the pipeline does not start with a registered dataset.
            compute_targets (List[ComputeTarget]): List of 1 or more Compute target instances to run the pipeline.
                The compute targets are currently utilized by the steps in the order in which they are specified.
                If len(compute_targets) > #steps, some compute targets at the ends of the list may not be utilized.
                If len(compute_targets) == #steps, all compute targets will be utilized with exactly 1 step.
                If len(compute_targets) < #steps, the compute targets at the start of the list may be utilized more.
            steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.
            step_factory (Callable[[Type[BasePipelineStep], StepConfig], BasePipelineStep], optional): Function to be
                used for creating a new instance of BasePipelineStep. This allows user to control how to create
                instances of different reusable step classes they have in their pipeline.
                Leave it as None to use the default function.
                Defaults to None.

        Raises:
            ValueError: If no ComputeTarget objects are specified, if steps_info is an empty list,
                or if input dataset names have invalid characters.
        """
        if len(compute_targets) == 0:
            raise ValueError("No ComputeTarget objects specified.")
        self.compute_targets = compute_targets

        validate_steps_info(steps_info)
        self._steps_info: List[PipelineStepInfo] = steps_info

        # Add the pipeline input dataset to list of first step input datasets.
        # pipeline_input_datasets is a List passed by reference (Python standard), we are modifying it in-place here.
        pipeline_input_datasets = self._steps_info[0].step_config.inputs
        validate_dataset_names(input_datasets)
        for dataset_name in input_datasets:
            if dataset_name not in pipeline_input_datasets:
                pipeline_input_datasets.append(dataset_name)

        self._steps = None

        self.step_factory = step_factory if step_factory else self._default_step_factory

    @property
    def steps_info(self) -> List[PipelineStepInfo]:
        """Property to return the current list of step info of this pipeline.

        Returns:
            List[PipelineStepInfo]: A copy of current step info list.
        """
        return self._steps_info[:]

    @steps_info.setter
    @typechecked
    def steps_info(self, value: List[PipelineStepInfo]):
        """Setting the value of step info of this pipeline.
        Setting this value will also reset the steps instances associated with this pipeline.

        Args:
            value (List[PipelineStepInfo]): The new list step info.

        Raises:
            ValueError: Raised if value is an empty list.
        """
        if len(value) == 0:
            raise ValueError("steps_info cannot be set to an empty list.")

        self._steps_info = value
        self._create_pipeline_steps(self.compute_targets)

    @property
    def steps(self) -> List[PipelineStep]:
        """Property for accessing list of steps in this pipeline.

        Returns:
            List[PipelineStep]: The list of PipelineStep instances used for this pipeline.
        """
        # First time getting steps will create the steps.
        if self._steps is None:
            self._steps = self._create_pipeline_steps(self.compute_targets)
        return self._steps[:]

    @typechecked
    def submit(self, experiment: Experiment,  # pylint: disable=too-many-arguments
               pipeline_parameters: Dict[str, Any] = None,
               wait_for_completion=False,
               add_zendikon_feed: bool = False, personal_access_token: str = None) -> Run:
        """Method to submit the pipeline to AML for execution.
        The pipeline is created using Zendikon package, so it will need to authenticate to Zendikon Pip feed to install
        the package when creating the pipeline docker image.

        Args:
            experiment (Experiment): The experiment instance to submit this pipeline to.
            pipeline_parameters (Dict[str, Any], optional): Pipeline parameters and values
                to add to the pipeline.
                Defaulted to None.
            wait_for_completion (bool, optional): Whether to wait for the pipeline to finish.
                Setting this option will be blocking your workflow.
                Defaults to False.
            add_zendikon_feed (bool, optional): Whether to add PAT to authenticate to Zendikon feed.
                This only needs to happen once per AML Workspace.
                Defaults to False.
            personal_access_token ([type], optional): The token to authenticate to Zendikon Pip feed.
                Defaults to None.

        Returns:
            Run: The run instance of the pipeline.
        """

        workspace = experiment.workspace

        if add_zendikon_feed:
            if personal_access_token is None:
                raise ValueError("Personal access token cannot be None if add_zendikon_feed is True. Must be a string.")

            # Set the personal access token for the workspace to access Zendikon Pip feed
            pat_token = personal_access_token
            workspace.set_connection(name="PAT for installing Zendikon",
                                     category="PythonFeed",
                                     target="https://pkgs.dev.azure.com",
                                     authType="PAT",
                                     value=pat_token)

        pipeline = AmlPipeline(workspace, steps=self.steps)
        if pipeline_parameters is not None:
            run = experiment.submit(
                pipeline, pipeline_parameters=pipeline_parameters)
        else:
            run = experiment.submit(pipeline)
        if wait_for_completion:
            run.wait_for_completion(show_output=True)

        return run

    @classmethod
    def _default_step_factory(cls, step_class: Type[BasePipelineStep], step_config: StepConfig) -> BasePipelineStep:
        """Default function to be used for creating a new BasePipelineStep instance from provided step_config
        and given the class to initialized the instance with.

        Args:
            step_class (Type[BasePipelineStep]): The class to initialized the step instance with.
            step_config (StepConfig): the step configuration to create the instance.

        Returns:
            BasePipelineStep: The instance of reusable step.
        """
        return step_class(step_config)

    def _create_pipeline_steps(self, compute_targets: List[ComputeTarget]) -> List[PipelineStep]:
        """Helper method to create the list of Python Script Step that are associated with the reusable steps in this
        pipeline. The list of steps resulted by calling this function will be accessible via the steps property.

        Args:
            compute_targets (List[ComputeTarget]): List of compute target(s) to execute the steps on.
                This is a hard requirement from AML SDK.

        Returns:
            List[PipelineStep]: The list of PythonScriptStep instances.
                Using PipelineStep class here to support for type of steps later.
        """

        python_script_steps = []
        num_compute_targets, compute_target_id = len(compute_targets), 0

        # mapping dataset with corresponding PipelineData object for dependency construction
        dependency_data = {}
        for step_info in self.steps_info:
            # We only need to create a PipelineData object for output datasets
            # Reason: the connection between 2 steps can only happen as: output_step1 -> input_step2
            for dataset_name in step_info.step_config.outputs:
                if dataset_name not in dependency_data:
                    dependency_data[dataset_name] = PipelineData(dataset_name)

        for step_info in self.steps_info:
            config = step_info.step_config
            compute_target = compute_targets[compute_target_id]
            # Creating Python Script Step
            script_step = self.step_factory(step_info.step_class, config).create_step(compute_target, dependency_data)
            python_script_steps.append(script_step)

            # Round-robin compute target allocation
            # TODO: change allocation method to round robin per dependency order in a future iteration.
            compute_target_id = (compute_target_id + 1) % num_compute_targets

        return python_script_steps
