"""
Handler for `create` subcommand.
"""
import sys

import click

from zendikon.spark_standalone_cluster import create_images
from zendikon.utils.env import check_installed


SPARK_STANDALONE_CLUSTER_CREATED_MSG = (
    "Spark Standalone Cluster successfully created. Run the following command to"
    " spin-up the cluster: `zendikon spark-standalone-cluster start`."
)


@click.command("create")
def create_spark_standalone_cluster():
    """
    Subcommand to create a new Spark Standlone Cluster.
    """
    if not (check_installed("docker") and create_images()):
        sys.exit(1)
    print(SPARK_STANDALONE_CLUSTER_CREATED_MSG)
