"""
Handler for `run` subcommand.
"""
import os
import sys

import click

from zendikon.utils.env import check_installed
from zendikon.spark_standalone_cluster.docker import PortFromConfig
from zendikon.spark_standalone_cluster import check_images_created, spin_up_containers

SPARK_STANDALONE_CLUSTER_WORKERS_OPT = "--workers"
SPARK_STANDALONE_CLUSTER_WORKERS_VAL = 2
SPARK_STANDALONE_CLUSTER_DETACH_OPT = "--detach/--no-detach"
SPARK_STANDALONE_CLUSTER_DETACH_VAL = True
SPARK_STANDALONE_CLUSTER_RUNNING_MSG = (
    "Spark Standalone Cluster is running.\n"
    "***********************************************************\n"
    "     Spark Master running at: 'spark://localhost:{spark_port}'\n"
    "  Hadoop NameNode running at: 'hdfs://localhost:{hadoop_port}'\n"
    "***********************************************************\n\n"
    "Checkout the following web UIs for more details on the cluster:\n"
    "***********************************************************\n"
    "             Spark Master UI: http://localhost:{spark_ui_port}/\n"
    "          Hadoop Namenode UI: http://localhost:{hadoop_ui_port}/\n"
    "  Hadoop Resource Manager UI: http://localhost:{hadoop_res_ui_port}/\n"
    "       Hadoop Job History UI: http://localhost:{hadoop_job_ui_port}/\n"
    "***********************************************************\n"
)


@click.command("start")
@click.option(
    SPARK_STANDALONE_CLUSTER_DETACH_OPT,
    default=SPARK_STANDALONE_CLUSTER_DETACH_VAL,
    show_default=True,
    help=(
        f"`{SPARK_STANDALONE_CLUSTER_DETACH_OPT}` will run containers in the"
        " background and return or display the container logs in stdout until"
        " they are spun-down, respectively."
    ),
)
@click.option(
    SPARK_STANDALONE_CLUSTER_WORKERS_OPT,
    default=SPARK_STANDALONE_CLUSTER_WORKERS_VAL,
    show_default=True,
    help=(  # TODO: [7296] spark-worker-limit
        "The number of Spark worker nodes to spin-up in the cluster. Currently only up"
        " to 2 workers are supported."
    ),
)
def start_spark_standalone_cluster(detach: bool, workers: int):
    """
    Subcommand to start the Spark Standalone Cluster.
    """
    if not (
        check_installed("docker-compose")
        and check_images_created()
        and spin_up_containers(workers, detach)
    ):
        sys.exit(1)

    print(SPARK_STANDALONE_CLUSTER_RUNNING_MSG.format(
        spark_port=os.getenv(PortFromConfig.SPARK_MASTER.value),
        hadoop_port=os.getenv(PortFromConfig.HADOOP_NAMENODE.value),
        spark_ui_port=os.getenv(PortFromConfig.SPARK_MASTER_UI.value),
        hadoop_ui_port=os.getenv(PortFromConfig.HADOOP_NAMENODE_UI.value),
        hadoop_res_ui_port=os.getenv(PortFromConfig.HADOOP_RES_MANAGER_UI.value),
        hadoop_job_ui_port=os.getenv(PortFromConfig.HADOOP_JOB_HISTORY_UI.value)
    ))
