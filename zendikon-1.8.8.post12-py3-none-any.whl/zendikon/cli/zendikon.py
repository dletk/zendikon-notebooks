"""
Main module to run command line interface
"""
import click

from zendikon.cli.aml import aml_command_group
from zendikon.cli.spark_standalone_cluster import spark_standalone_cluster_command_group


@click.group()
def zendikon_command_group():
    """
    Main function for the Zendikon CLI
    """


zendikon_command_group.add_command(spark_standalone_cluster_command_group)
zendikon_command_group.add_command(aml_command_group)
