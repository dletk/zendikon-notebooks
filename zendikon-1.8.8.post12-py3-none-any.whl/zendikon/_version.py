"""Reference for the current Zendikon version.
"""

VERSION = "1.8.8r12"
