"""Module containing the definition for the Metric base class.
Other custom metric classes should inherit from this class if needed.
"""
import json
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Union
from uuid import UUID, uuid4

from typeguard import typechecked


class MetricName(str, Enum):
    """Representing different Metric names that can be used with the Metric class.
    These are commonly known metrics only. Models producing other metrics should extend this class
    and add their own metric name constant.
    """

    PRECISION = "precision"
    RECALL = "recall"

    # Refer to the complete list at:
    # from azureml.automl.core.shared.constants import Metric
    MAPE = 'mean_absolute_percentage_error'
    SMAPE = 'symmetric_mean_absolute_percentage_error'
    RMSE = 'root_mean_squared_error'
    RMSLE = 'root_mean_squared_log_error'
    NORM_RMSE = 'normalized_root_mean_squared_error'
    NORM_RMSLE = 'normalized_root_mean_squared_log_error'


class Metric():
    """The class representing a Metric to be tracked by a pipeline or model. This class implements
    the default behavior for comparing, serializing and deserializing metric instances. Custom metric
    with different behavior should extend this class and override the default, if needed.
    """

    JSON_PROPERTY_NAME: str = "name"
    JSON_PROPERTY_VALUE: str = "value"
    JSON_PROPERTY_ID: str = "id_"
    JSON_PROPERTY_MODEL_ID: str = "model_id"
    JSON_PROPERTY_METRIC_CLASS: str = "metric_class"

    @typechecked
    def __init__(self, name: Union[MetricName, str], value: float, model_id: UUID, id_: UUID = None) -> None:
        """Create an instance of Metric.

        Args:
            name (Union[MetricName, str]): Name of this metric instance. This is used to distinguish between metrics in
                the same model, such as Precision, RMSE,...
            value (float): The value of this metric to be recorded.
            model_id (UUID): ID of the model instance which this metric instance is associated with.
            id_ (UUID, optional): ID of this metric instance. This will be randomly-generated if None.
                Defaults to None.
        """
        self.name = name
        self.value = value

        self.model_id = model_id

        self.id_ = id_ if id_ is not None else uuid4()

    @classmethod
    @typechecked
    def from_json(cls, path: Union[Path, str]) -> "Metric":
        """Deserialize a JSON file to a Metric instance.
        The exact Metric class to deserialize the JSON file will be determined based on the
        metric class information in the JSON content, or the Metric class being used to call this method.
        If the Metric class calling this method and the metric class information presented in the JSON content
        do not match, an error will be raised.

        Args:
            path (Union[Path, str]): Path to JSON file to load the Metric instance.

        Raises:
            ValueError: raised if the provided path does not exist.

        Returns:
            Metric: An instance of Metric representing the metric information provided by the JSON content.
        """

        path = Path(path) if isinstance(path, Path) else path

        if not path.exists():
            raise ValueError(f"path: {path.as_posix()} does not exist")

        with open(path, "r") as json_file:
            obj_dict = json.load(json_file)

            if not (cls.JSON_PROPERTY_ID in obj_dict and
                    cls.JSON_PROPERTY_NAME in obj_dict and
                    cls.JSON_PROPERTY_MODEL_ID in obj_dict and
                    cls.JSON_PROPERTY_VALUE in obj_dict and
                    cls.JSON_PROPERTY_METRIC_CLASS in obj_dict):
                raise ValueError("JSON file does not follow the expected schema for a Metric instance.")

        expected_class = obj_dict[cls.JSON_PROPERTY_METRIC_CLASS]
        target_class = cls.__name__

        if expected_class != target_class:
            raise ValueError(f"The current JSON file is representing a metric of class: {expected_class}, "
                             f"but you are using: {target_class} to deserialize this JSON.")

        return cls(name=obj_dict[cls.JSON_PROPERTY_NAME],
                   value=obj_dict[cls.JSON_PROPERTY_VALUE],
                   model_id=UUID(obj_dict[cls.JSON_PROPERTY_MODEL_ID]),
                   id_=UUID(obj_dict[cls.JSON_PROPERTY_ID]))

    @typechecked
    def to_json(self, path: Union[Path, str]) -> Dict[str, Any]:
        """Serialize the current Metric instance to a JSON file.
        Args:
            path (Union[Path, str]): Path the output file to save the JSON content.

        Returns:
            Dict[str, Any]: The JSON content written to the output file.
        """
        json_content = {
            self.JSON_PROPERTY_NAME: self.name,
            self.JSON_PROPERTY_VALUE: self.value,
            self.JSON_PROPERTY_ID: str(self.id_),
            self.JSON_PROPERTY_MODEL_ID: str(self.model_id),
            self.JSON_PROPERTY_METRIC_CLASS: self.__class__.__name__
        }

        path = path if isinstance(path, Path) else Path(path)

        with open(path, "w") as json_file:
            json.dump(json_content, json_file)

        return json_content

    def __str__(self) -> str:
        return f"Metric: {self.name} | Model: {self.model_id} | Value: {self.value} | ID: {self.id_}"

    def __repr__(self) -> str:
        return f"Metric: {self.name} | Model: {self.model_id} | Value: {self.value} | ID: {self.id_}"

    def __eq__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value == other.value

    def __ne__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value != other.value

    def __le__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value <= other.value

    def __ge__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value >= other.value

    def __lt__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value < other.value

    def __gt__(self, other: object) -> bool:
        self.__validate_comparability(other)
        return self.value > other.value

    def __validate_comparability(self, __o: object) -> bool:
        """Helper method to check whether it is valid to compare the current Metric instance with the provided object.
        If the object does not belong to the same class, i.e., a different metric class, then it does not make sense to
        compare these 2 metric instance together. If the metric name is different, we will still allow the comparison to
        be executed, but provide a warning these are 2 different kinds of metric.

        Args:
            __o (object): The object to be compared with the current Metric instance.
                Ideally should be another metric instance.

        Raises:
            TypeError: Raised if the provided object is not an instance of the same Metric class.

        Returns:
            bool: True if the provided object can be safely compare with the current Metric instance.`
        """
        if not isinstance(__o, self.__class__):
            raise TypeError(f"Cannot compare object of type {self.__class__} with object of type {__o.__class__}")

        if self.name != __o.name:
            print(f"WARNING: Comparing 2 different kinds of metric: {self.name} and {__o.name}.")

        return True
