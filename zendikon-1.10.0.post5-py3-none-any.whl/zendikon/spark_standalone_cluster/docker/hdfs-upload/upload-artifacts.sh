# Upload model artifacts into HDFS cluster 
# (must have existing HDFS live on the host 'spark-master')

#!/bin/bash
ln -sf /dev/stdout ./stdout.out

# Turn off hadoop safe mode so we can upload files immediate after cluster is launched
$HADOOP_HOME/bin/hdfs dfsadmin -safemode leave \
>> ./stdout.out
$HADOOP_HOME/bin/hdfs dfs -mkdir -p artifacts \
>> ./stdout.out
$HADOOP_HOME/bin/hdfs dfs -put -f /artifacts/* artifacts \
>> ./stdout.out
$HADOOP_HOME/bin/hdfs dfs -ls -R /user/root/artifacts \
>> ./stdout.out
# Given global file access to the "/user" folder 
# This allows ANYONE to write to cluster
$HADOOP_HOME/bin/hdfs dfs -chmod -R 777 /user \
>> ./stdout.out