"""
Zendikon module init file.
"""
import logging
import os
from distutils.util import strtobool

from ._version import VERSION

__version__ = VERSION

logger = logging.getLogger(__name__)

if strtobool(os.getenv("ZENDIKON_DEBUG", "false")):
    logger.setLevel(logging.DEBUG)
    hdlr = logging.StreamHandler()
    hdlr.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(module)s | %(funcName)s |"
        " %(lineno)d | %(message)s"
    )
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.debug("zendikon logging enabled")
else:
    logger.addHandler(logging.NullHandler())
