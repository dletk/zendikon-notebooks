"""
Module contains utility functions for other components in aml pipeline package
"""
import argparse
import re
from typing import List, Sequence

from typeguard import typechecked

from zendikon.aml.types import StepArgument


@typechecked
def get_argument_values_from_separated_string(arg_name: str,
                                              args: argparse.Namespace,
                                              separator: str = ",",) -> List[str]:
    """Helper function to split a string separated by a symbol, such as comma, -,
    to a list of string values.

    Args:
        arg_name (str): The name of the argument to search to find value for.
        args (argparse.Namespace): The namespace containing arguments and the string value.
        separator (str, optional): The separator used to separate individual value in the
            argument string value.
            Defaults to ",".

    Returns:
        List[str]: List of splitted values for the input argument.
    Raises:
        KeyError: The arg_name provided is not in the argparse namespace.
    """
    values = []

    dict_args = vars(args)
    # This will raise KeyError
    values_str = dict_args[arg_name]
    if isinstance(values_str, str):
        values = [val.strip() for val in values_str.split(separator) if val]

    return values


@typechecked
def parse_arguments(arguments: List[StepArgument] = None) -> argparse.Namespace:
    """Function to register and parse arguments from CLI and store the value in an
    argparse Namespace object to access later. If there is no arguments list provided,
    this function will return a default, empty argparse Namespace

    Args:
        arguments (List[StepArgument], optional): The list of StepArgument indicating
            the argument name, the type, the help message and optional default value
            for that argument.
            Defaults to None.

    Returns:
        argparse.Namespace: The namespace object containing parsed argument values.
    """

    if arguments is None or len(arguments) == 0:
        return argparse.Namespace()

    parser = argparse.ArgumentParser()
    for argument in arguments:
        if argument.data_type == bool:
            parser.add_argument(f"--{argument.name}", type=lambda x: (str(x).lower() == 'true'),
                                help=argument.helper_message,
                                default=argument.default_value, required=argument.required)
        else:
            parser.add_argument(f"--{argument.name}", type=argument.data_type,
                                help=argument.helper_message,
                                default=argument.default_value, required=argument.required)
    args = parser.parse_args()

    return args


@typechecked
def validate_dataset_names(datasets: Sequence[str]) -> bool:
    """Function to validate whether the list of dataset names follow some basic requirements
    in naming convention. These requirements is different with AML in order to make sure our
    Zendikon component can work correctly.

    Notice: An empty list is a valid option.

    Args:
        datasets (Sequence[str]): The list or the tuple of dataset names to validate.

    Raises:
        ValueError: Raised if one of the name in the list does not follow the naming convention.

    Returns:
        bool: True if all names in the list follow the naming convention.
    """

    for ds_name in datasets:
        if len(ds_name) == 0 or len(ds_name.strip()) == 0:
            raise ValueError(
                "Dataset name is an empty string or whitespace string")
        # Currently AML allows any string for Dataset name.
        # However, we are going to restricting it to letters, numbers, - and _
        if not bool(re.fullmatch(r"[a-zA-Z0-9\-_/]+", ds_name)):
            raise ValueError(
                f"Dataset name can only contains letters, numbers, - and _ character. Get: {ds_name}")

    return True
