"""Helper module containing implementation of the Reusable pipeline step info class.
"""

from typing import Type

from typeguard import typechecked
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig

class PipelineStepInfo:
    """Class to contain the information of a step in the pipeline.
    """

    @typechecked
    def __init__(self, step_class: Type[BasePipelineStep], step_config: StepConfig):
        """Create a new instance of PipelineStepInfo

        Args:
            step_class (Type[BasePipelineStep]): The type of BasePipelineStep this step will be created with.
            step_config (StepConfig): The configuration for creating the step.
        """
        self.step_class = step_class
        self.step_config = step_config
