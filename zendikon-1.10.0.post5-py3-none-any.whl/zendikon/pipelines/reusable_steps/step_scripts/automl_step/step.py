"""Implementation for the AutoML reusable step that utilize AML AutoML.
"""

import argparse
import os
from typing import Optional
import joblib

from azureml.core import Dataset, Run
from azureml.train.automl import AutoMLConfig
from azureml.train.automl.run import AutoMLRun
from azureml.core.compute import ComputeTarget

from zendikon.aml.mixed_data_step_decorator import FILE, TABULAR, AmlPipelineStep
from zendikon.aml.step_decorator import AbstractAmlPythonStepCompatible
from zendikon.aml.utils import get_argument_values_from_separated_string
from zendikon.pipelines.reusable_steps.automl_step import ZendikonAutoMLStep
from zendikon.pipelines.utils import get_models_and_metrics_from_automl_run


@AmlPipelineStep(input_types=[TABULAR], output_types=[FILE, FILE])
def run_step(training_data, cli_args: Optional[argparse.Namespace] = None, run: Optional[Run] = None):
    """Main function to execute the step.

    Args:
        training_data (pd.DataFrame): the input data loaded in a pd.DataFrame.
        cli_args (argparse.Namespace, optional): The CLI arguments parsed namespace.
            Defaults to None.
        run (Run): The current AML run instance.
            Defaults to None.
    """

    # TODO: This is a hack to work around, we definitely want to get the instance of registered dataset here
    # from the Decorator instead.
    input_dataset_name = get_argument_values_from_separated_string(
        AbstractAmlPythonStepCompatible.NAMED_INPUT_DATASETS_ARG_NAME, cli_args)[0]

    workspace = run.experiment.workspace

    training_data = Dataset.get_by_name(workspace, name=input_dataset_name)

    automl_config_dict = joblib.load(f"./{ZendikonAutoMLStep.AUTOML_CONFIG_FILENAME}")

    # pylint: disable=E0110
    automl_config_dict["compute_target"] = ComputeTarget(workspace, automl_config_dict["compute_target"])

    automl_run = run.submit_child(AutoMLConfig(**automl_config_dict, training_data=training_data))
    automl_run.wait_for_completion()

    models_info = get_models_and_metrics_from_automl_run(automl_run)
    print(models_info)

    # Register models_info
    models_info_output_folder = "./models_info"
    os.makedirs(models_info_output_folder, exist_ok=True)

    models_info_path = models_info_output_folder + "/models_info.pkl"
    joblib.dump(models_info, models_info_path)

    # Obtain the best model selected by primary metric
    best_model_output_folder = "./best_model"
    os.makedirs(best_model_output_folder, exist_ok=True)

    # The run instance returned by submit_child is not of type AutoMLRun
    automl_run = AutoMLRun(automl_run.experiment, run_id=automl_run.id)
    best_run, model = automl_run.get_output()
    print(best_run)
    print(model)
    model_path = best_model_output_folder + "/model.pkl"
    joblib.dump(model, model_path)

    return [models_info_output_folder, best_model_output_folder]


if __name__ == "__main__":
    # pylint: disable=E1120
    run_step()
