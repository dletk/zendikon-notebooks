"""Module containing the implementation for Time Series Anomaly Detection Reusable pipeline.
"""

from typing import List, Callable, Type, Sequence

from azureml.core import ComputeTarget
from typeguard import typechecked

from zendikon.pipelines.reusable_pipeline import AbstractReusablePipeline
from zendikon.pipelines.pipeline import PipelineStepInfo
from zendikon.pipelines.step.step_config import StepConfig
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.time_series.anomaly_detection.steps import MerlionModelsTrainingStep


class TimeSeriesAnomalyDetection(AbstractReusablePipeline):
    """Class represents a time series anomaly detection reusable pipeline.
    This class includes a default implementation of the pipeline with pre-determined steps.
    User can obtain the default step infos to learn about what steps we are using to construct the pipeline,
    as well as overriding the steps as they want. Keep in mind, once you override the default pipeline steps infos,
    you are responsible for making sure the data transfer between your steps correctly.

    In order to create the pipeline with default steps, simply do::

        pipeline = TimeSeriesAnomalyDetection.from_default_steps_info(...)

    """

    _DEFAULT_STEPS_INFO: List[PipelineStepInfo] = [
        PipelineStepInfo(MerlionModelsTrainingStep,
                         StepConfig("Train Merlion models", outputs=["anomaly_detection_merlion_models"]))
    ]

    @typechecked
    def __init__(self, input_dataset: str,  # pylint: disable=R0913
                 time_column: str,
                 target_columns: Sequence[str],
                 compute_targets: List[ComputeTarget],
                 steps_info: List[PipelineStepInfo],
                 step_factory: Callable[[Type[BasePipelineStep], StepConfig], BasePipelineStep] = None) -> None:

        self.time_column = time_column
        self.target_columns = target_columns
        if step_factory is None:
            step_factory = self._step_factory

        super().__init__([input_dataset], compute_targets, steps_info, step_factory=step_factory)

    @classmethod
    @typechecked
    def _get_default_steps_info(cls) -> List[PipelineStepInfo]:
        """Private method to get the default steps info for this pipeline.
        The return value of this method will then be exposed via a read-only class property.

        Returns:
            List[PipelineStepInfo]: The list of default steps info.
        """

        return cls._DEFAULT_STEPS_INFO

    @classmethod
    @typechecked
    def from_default_steps_info(cls, input_dataset: str,  # pylint: disable=arguments-differ
                                time_column: str, target_columns: Sequence[str],
                                compute_targets: List[ComputeTarget]) -> "TimeSeriesAnomalyDetection":
        """Method to create a Time Series Anomaly Detection pipeline using the default steps info.

        Args:
            input_datasets (str): The input dataset to the pipeline.
            time_column (str): The column containing time stamp in the input dataset.
            target_columns (Sequence[str]): The columns to perform anomaly detection.
            compute_targets (List[ComputeTarget]): The list of compute targets to execute the pipeline on.
        """
        return cls(input_dataset=input_dataset, time_column=time_column, target_columns=target_columns,
                   compute_targets=compute_targets,
                   steps_info=cls.default_steps_info)

    def _step_factory(self, step_class: Type[BasePipelineStep], step_config: StepConfig) -> BasePipelineStep:
        """Helper method to create a PipelineStep instance based on the provided step_config. Because there are
        additional information needed to create steps in this anomaly detection pipeline, we create this method
        instead of using the default factory method from the BasePipeline class.

        Args:
            step_class (Type[BasePipelineStep]): The Step type to create an instance of.
            step_config (StepConfig): The configuration to provide for the associated step instance.

        Returns:
            BasePipelineStep: The instance of a pipeline with configuration based on step_config.
        """

        if step_class is not MerlionModelsTrainingStep:
            return step_class(step_config)

        arguments = {"time_column": self.time_column, "target_columns": ",".join(self.target_columns)}
        # Only add the arguments if the current arguments dict does not contain them
        step_config.arguments = {**arguments, **step_config.arguments}

        return MerlionModelsTrainingStep(step_config)
