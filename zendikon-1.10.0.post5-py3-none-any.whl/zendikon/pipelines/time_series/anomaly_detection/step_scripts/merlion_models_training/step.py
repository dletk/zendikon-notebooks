"""Step to train Anomaly detection models and provide the comparsion between those models.
"""

import argparse
from typing import List

import pandas as pd
from sklearn.model_selection import train_test_split
from azureml.core.run import Run

from zendikon.aml.mixed_data_step_decorator import FILE, TABULAR, AmlPipelineStep
from zendikon.aml.types import StepArgument
from zendikon.pipelines.time_series.anomaly_detection.utils.merlion_models import (
    train_merlion_models, test_merlion_models
)


@AmlPipelineStep(
    input_types=[TABULAR], output_types=[FILE],
    step_arguments=[
        StepArgument("time_column", "Column indicate the time stamp"),
        StepArgument("target_columns", "Comma-seprated list, columns to perform anomaly detection on", str),
        StepArgument("test_ratio", "Ratio to reserve for testing in the input data", float, default_value=0.2)
    ])
def step_run(data: pd.DataFrame, cli_args: argparse.Namespace = None, run: Run = None) -> List[str]:
    """Main function to execute the Anomaly detection models training.

    Args:
        data (pd.DataFrame): The time series data containing the time_column and the target_columns.
        cli_args (argparse.Namespace, optional): The CLI arguments parsed namespace.
            Defaults to None.
        run (Run): The current AML run instance.
            Defaults to None.
    """

    output_dir = "outputs/models"

    target_columns = [col.strip() for col in cli_args.target_columns.split(",")]

    data = data[target_columns+[cli_args.time_column]]

    # The Merlion models require the data to have timeStamp as index
    data = data.set_index(cli_args.time_column).sort_index()

    train_df, test_df = train_test_split(data, test_size=cli_args.test_ratio, shuffle=False)

    trained_models = train_merlion_models(train_df)

    test_results = test_merlion_models(test_df, train_df, trained_models)

    for model_name in test_results:
        model = trained_models[model_name]
        fig, _ = test_results[model_name]

        model_output = f"{output_dir}/{model_name}"
        prediction_plot_file = f"{model_output}/{model_name}_prediction_plot.png"

        # Save model files and prediction plot to outputs folder for registering as output of the run
        model.save(model_output)
        fig.savefig(prediction_plot_file)

        # Log information to AML portal for easier UX
        run.log_image(f"{model_name}", prediction_plot_file)

    return [output_dir]


if __name__ == "__main__":
    step_run()  # pylint: disable=E1120
