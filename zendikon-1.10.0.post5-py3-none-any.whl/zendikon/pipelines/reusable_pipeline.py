"""Module containing the implementation for AbstractReusablePipeline class.
This class should be used as the base class for all reusable pipelines.
"""

from typing import List

from zendikon.pipelines.pipeline import Pipeline, PipelineStepInfo


class _MetaclassReusablePipeline(type):
    """Meta class to provide a class property default_steps_info for ReusablePipeline class.

    Python does not have class property built-in. Providing a custom metaclass is the easiest
    route for read-only property. Refers to this link:
    https://stackoverflow.com/questions/5189699/how-to-make-a-class-property
    """

    @property
    def default_steps_info(cls) -> List[PipelineStepInfo]:
        """The default list of PipelineStepInfo used by the current class to construct a reusable pipeline.

        Returns:
           List[PipelineStepInfo]: A copy of the default list.
        """
        try:
            # Return a copy to avoid modification, because Python is pass by reference.
            return cls._get_default_steps_info()[:]
        except AttributeError:
            # Hiding the actual implementation
            raise AttributeError(f"{cls.__name__} does not provide a default steps info.") from None


class AbstractReusablePipeline(Pipeline, metaclass=_MetaclassReusablePipeline):
    """Class to represent a reusable pipeline.
    A reusable pipeline has a list of default steps info that it will execute.
    The relationship between steps in this type of pipeline is pre-determined. User should examine
    the default steps info if they want to modify the pipeline.
    """

    @classmethod
    def _get_default_steps_info(cls) -> List[PipelineStepInfo]:
        """Private abstract method to get the default steps info for this pipeline.
        The return value of this method will then be exposed via a read-only class property.

        Python does not have an easy way to work with

        Raises:
            NotImplementedError: Raised if this method is not implemented by the derived class.

        Returns:
            List[PipelineStepInfo]: The list of default steps info.
        """
        raise NotImplementedError

    @classmethod
    def from_default_steps_info(cls, *args, **kwargs):
        """Based method for creating an instance of this ReusablePipeline using the default Steps info.
        Additional parameters required for this function should be specificed in the actual implementation
        of derived class.

        Raises:
            NotImplementedError: Raised if this method is not implemented by the derived class.
        """
        raise NotImplementedError
