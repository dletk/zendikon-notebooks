"""Module containing the reusable pipeline implementation for Time Series Forecasting.
"""
import logging
from typing import Any, Dict, List, Sequence, Type

from azureml.core import ComputeTarget
from azureml.automl.core.shared.constants import Metric, Tasks
from azureml.train.automl import AutoMLConfig
from typeguard import typechecked

from zendikon.pipelines.pipeline import PipelineStepInfo
from zendikon.pipelines.reusable_pipeline import AbstractReusablePipeline
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.reusable_steps.automl_step import ZendikonAutoMLStep
from zendikon.pipelines.step.step_config import StepConfig


class AutoMLPipeline(AbstractReusablePipeline):
    """The class represents a reusable pipeline that uses AutoML implementation.
    """

    DEFAULT_AUTOML_CONFIG_DICT = dict(
        # Blocking Prophet because installing fbprophet is not stable
        blocked_models=["Prophet"],
        enable_early_stopping=True,
        n_cross_validations=3,
        verbosity=logging.INFO,
    )

    _DEFAULT_STEPS_INFO: List[PipelineStepInfo] = [
        PipelineStepInfo(ZendikonAutoMLStep,
                         StepConfig("zendikon_automl", inputs=[], outputs=["automl_models_info", "best_model"]))
    ]

    _SUPPORTED_TASKS = [Tasks.REGRESSION, Tasks.CLASSIFICATION, Tasks.FORECASTING]

    @classmethod
    def _get_default_steps_info(cls) -> List[PipelineStepInfo]:
        """Private abstract method to get the default steps info for this pipeline.
        The return value of this method will then be exposed via a read-only class property.

        Python does not have an easy way to work with

        Raises:
            NotImplementedError: Raised if this method is not implemented by the derived class.

        Returns:
            List[PipelineStepInfo]: The list of default steps info.
        """
        return cls._DEFAULT_STEPS_INFO

    @typechecked
    def __init__(self, input_datasets: Sequence[str],  # pylint: disable-msg=too-many-arguments
                 task: str,
                 primary_metric: str,
                 compute_targets: List[ComputeTarget],
                 label_column_name: str,
                 automl_config: Dict[str, Any],
                 steps_info: List[PipelineStepInfo]) -> None:
        """Create an instance of AutoML reusable pipeline.

        Args:
            input_datasets (Sequence[str]): Names of the input datasets of the pipeline.
            task (str): The AutoML task to create this pipeline with.
                Please refer to AML AutoML documentation.
            primary_metric (str): The primary metric to evaluate the trained models.
                Please refer to AML AutoML documentation.
            compute_targets (List[ComputeTarget]): One or more Compute target instances to run the pipeline.
            label_column_name (str): Name of the target column to perform the task on.
            automl_config (Dict[str, Any]): The configuration to set up AML AutoML.
                Please refer to AutoMLConfig documentation.
            steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.
        """
        if automl_config.get("compute_target") is None and len(compute_targets) != 0:
            automl_config["compute_target"] = compute_targets[0].name

        if primary_metric not in Metric.FULL_SET:
            raise ValueError("primary_metric must be in the Metrics list of AutoML. Refer to AML AutoML documentation.")
        if task not in self._SUPPORTED_TASKS:
            raise ValueError(f"task must be one of: {self._SUPPORTED_TASKS}")

        automl_config["primary_metric"] = primary_metric
        automl_config["task"] = task
        automl_config["label_column_name"] = label_column_name

        # Validate whether the config dicts is useable
        AutoMLConfig(**automl_config)

        self._automl_config = automl_config

        super().__init__(input_datasets, compute_targets, steps_info, step_factory=self._step_factory)

    @classmethod
    # Python <3.7 cannot use the current class name annotate type, refer to PEP 484 - forward references
    # pylint: disable-msg=too-many-arguments
    def from_default_settings(cls, input_datasets: Sequence[str],
                              task: str,
                              primary_metric: str,
                              compute_targets: List[ComputeTarget],
                              label_column_name: str) -> "AutoMLPipeline":
        """Create an instance of AutoMLPipeline using the default configuration for AutoML config and step info.
        """
        return cls(input_datasets, task, primary_metric, compute_targets, label_column_name,
                   automl_config=cls.DEFAULT_AUTOML_CONFIG_DICT,
                   steps_info=cls.default_steps_info)

    @classmethod
    # pylint: disable-msg=too-many-arguments, arguments-differ
    def from_default_steps_info(cls, input_datasets: Sequence[str],
                                task: str,
                                primary_metric: str,
                                compute_targets: List[ComputeTarget],
                                automl_config: Dict[str, Any],
                                label_column_name: str) -> "AutoMLPipeline":
        """Create an instance of AutoMLPipeline using the default steps info.
        """
        return cls(input_datasets, task, primary_metric, compute_targets, label_column_name, automl_config,
                   steps_info=cls.default_steps_info)

    @classmethod
    # pylint: disable-msg=too-many-arguments
    def from_default_automl_config(cls, input_datasets: Sequence[str],
                                   task: str,
                                   primary_metric: str,
                                   compute_targets: List[ComputeTarget],
                                   label_column_name: str,
                                   steps_info: List[PipelineStepInfo]) -> "AutoMLPipeline":
        """Create an instance of AutoMLPipeline using the default AutoML config.
        """
        return cls(input_datasets, task, primary_metric, compute_targets, label_column_name,
                   steps_info=steps_info,
                   automl_config=cls.DEFAULT_AUTOML_CONFIG_DICT)

    @property
    def automl_config(self):
        """Property to return a copy of the current automl_config settings that will be used for
        creating this step in the pipeline.
        """
        return dict(self._automl_config)

    def _step_factory(self, step_class: Type[BasePipelineStep], step_config: StepConfig):
        if step_class is not ZendikonAutoMLStep:
            return step_class(step_config)

        return ZendikonAutoMLStep(self._automl_config, step_config)
