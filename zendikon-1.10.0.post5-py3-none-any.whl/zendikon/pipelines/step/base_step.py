"""Module containing the implementation of BasePipelineStep.
"""

import tempfile
import shutil
from pathlib import Path
from typing import Dict, Union
from typing_extensions import Literal

from azureml.core import ComputeTarget
from azureml.pipeline.core import PipelineData
from azureml.pipeline.steps import PythonScriptStep
from typeguard import typechecked

from zendikon.pipelines.step.step_config import StepConfig


class BasePipelineStep:
    """Class to represent a step in an ML pipeline created using Zendikon.
    This class allows you to control the configuration of a step and create associated PythonScriptStep (or other
    platform specific components) to be used in AML pipeline (or respective platform).
    """

    SCRIPT_NAME_DEFAULT = "step.py"

    @typechecked
    def __init__(self, step_config: StepConfig, source_directory: Path, script_name: str = None) -> None:
        """Create a new instance of BasePipelineStep.
        Creating an instance of BasePipelineStep is discouraged. Instead, try to create a subclass of this class
        that provides default value of source_directory and script_name in its constructor. This will allow a better
        understanding of steps within a pipeline, rather than relying on some step name, which cannot be used to
        enforce type checking,... as well as other semantic checks that can be done at pipeline build time.

        Args:
            step_config (StepConfig): The step configuration to create this step.
            source_directory (Path): The source directory where the actual .py file for this step located.
            script_name (str, optional): Name of the .py file used for this step in source_directory.
                Defaults to None.
        """
        if script_name is not None and len(script_name.strip()) == 0:
            raise ValueError("script_name cannot be an empty string.")

        self.script_name: str = script_name if script_name is not None else self.SCRIPT_NAME_DEFAULT
        self.step_config: StepConfig = step_config

        self.source_directory: Path = source_directory
        self.temp_source_directory: Path = Path(tempfile.mkdtemp()) / self.source_directory.parts[-1]

    @typechecked
    def create_step(self,
                    compute_target: Union[Literal["local"], ComputeTarget],
                    dependency_data: Dict[str, PipelineData] = None) -> PythonScriptStep:
        """Method to create a PythonScriptStep with the config provided to this step constructor.

        Args:
            compute_target (Union[Literal["local"], ComputeTarget]): The compute target to execute this step.
            dependency_data (Dict[str, PipelineData]): Mapping between dataset name and PipelineData object
                for automated dependency construction.

        Returns:
            PythonScriptStep: The instance of PythonScriptStep that can be included in an AML pipeline.
        """
        params = self.step_config.create_step_parameters(dependency_data)

        # Copying content in the source directory to a temp folder
        # for reproducibility and avoid permissions problem, if any
        shutil.copytree(self.source_directory, self.temp_source_directory)

        return PythonScriptStep(**params,
                                script_name=self.script_name,
                                compute_target=compute_target,
                                source_directory=self.temp_source_directory.as_posix())
