"""Module containing helper functions to perform some frequent tasks that are related to steps.
"""
from typing import List, Set

from typeguard import typechecked


@typechecked
def get_repeated_elements(elements : List[str]) -> Set[str]:
    """Helper method to get a set of duplicated strings from the input list of elements.

    Args:
        elements (List[str]): Input list of strings.

    Returns:
        Set[str]: Strings duplicated in the set.
    """
    unique_elems, repeated_elems = set(), set()
    for elem_name in elements:
        if elem_name in unique_elems:
            repeated_elems.add(elem_name)
        else:
            unique_elems.add(elem_name)
    return repeated_elems
