"""
Handler for `stop` subcommand.
"""
import sys

import click

from zendikon.spark_standalone_cluster import spin_down_containers
from zendikon.utils.env import check_installed


SPARK_STANDALONE_CLUSTER_STOP_MSG = "Spark Standalone Cluster stopped."


@click.command("stop")
def stop_spark_standalone_cluster():
    """
    Subcommand to stop the Spark Standalone Cluster.
    """
    if not (check_installed("docker-compose") and spin_down_containers()):
        sys.exit(1)
    print(SPARK_STANDALONE_CLUSTER_STOP_MSG)
