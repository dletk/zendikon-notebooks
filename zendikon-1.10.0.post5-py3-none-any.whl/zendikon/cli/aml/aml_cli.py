"""Module to manage the "aml" command group for AML related commands.
"""
import click

from zendikon.cli.aml.aml_pipeline_generator import generate_pipeline


@click.group("aml")
def aml_command_group():
    """Command group to manage all aml related components that are exposed via CLI.
    """


aml_command_group.add_command(generate_pipeline)
