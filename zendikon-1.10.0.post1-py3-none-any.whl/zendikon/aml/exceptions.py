"""Module containing Zendikon exception classes for aml pipeline.
"""


class ZendikonUserError(Exception):
    """Represent an exception to raise when there is a user error while working with Zendikon
    features. This exception will be used to categorize error caused by Zendikon features
    versus other UserError that is common to AML.
    """


class ZendikonInternalError(Exception):
    """Represent an exception caused by internal errors of Zendikon package.
    """

class ZendikonDatasetMismatchError(Exception):
    """Represent an exception happening when a user-specified dataset type does not match
    what is returned by AML Pipeline/Zendikon. The root cause is undetermined, so it does
    not fall into either User or Internal error.
    """
