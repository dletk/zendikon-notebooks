"""Module containing custom-defined types for Zendikon AML package
"""
import argparse
from typing import Callable, Any, List
from dataclasses import dataclass

LoadInputType = Callable[[argparse.Namespace, List[str]], List[Any]]
RegisterOutputType = Callable[[List[Any], List[str], Any, argparse.Namespace], List[Any]]


@dataclass
class StepArgument():
    """Class for keeping track of an step argument specified in a pipeline step.

    Args:
        name (str): Name of the CLI argument.
        helper_message (str): Short message explaining the usage of the CLI argument.
        data_type (type, optional): Data type of the CLI argument.
            Defaults to str.
        default_value (Any, optional): the default value for the CLI argument.
            Defaults to None.
        required (bool, optional): flag to indicate whether this CLI argument is required.
            If set to False, the argument will be set to default_value.
            If default_value is not provided, the argument will be set to None.
            If set to True, default_value will be ignored, and the argument must be provided.
            Defaults to False.
    """
    name: str
    helper_message: str
    data_type: type = str
    default_value: Any = None
    required: bool = False

    def __post_init__(self):
        if not (isinstance(self.name, str) and
                isinstance(self.data_type, type) and
                isinstance(self.helper_message, str) and
                isinstance(self.required, bool)):
            raise TypeError("Invalid argument type for creating StepArgument.")

        if self.default_value is not None and not isinstance(self.default_value, self.data_type):
            raise TypeError("Type of default value is different with the argument data type.")
