"""Module contains the implementation for TabularData Step decorator.
This decorator should be used with steps working with pandas Dataframe.
"""
import argparse
from typing import List, Any, Optional, Sequence

import pandas as pd
from azureml.data.tabular_dataset import TabularDataset
from azureml.core.dataset import Dataset
from typeguard import typechecked

from zendikon.aml.step_decorator import AbstractAmlPythonStepCompatible
from zendikon.aml.exceptions import ZendikonUserError
from zendikon.aml.utils import validate_dataset_names


class TabularDataAmlPythonStepCompatible(AbstractAmlPythonStepCompatible):
    """Class represent a Decorator to make a python function working with tabular data
    become a Python Script step. Currently we are supporting Pandas dataframe as the input
    and output type.

    The decorated function should return a List of Pandas DataFrame::

        def function_name(<input_data1>: pd.DataFrame, <input_data2>: pd.DataFrame, ....,
                          cli_args: argsparse.Namespace = None,
                          run: aml.core.run = None) -> List[pd.DataFrame].
            cli_args: the Namespace from argument parser contain all CLI arguments
            run: the Run instance if this step is run on AML

    """

    @typechecked
    def _parse_datasets_to_step_input(self,
                                      input_datasets: List[TabularDataset], cli_args: argparse.Namespace
                                      ) -> List[pd.DataFrame]:
        """The default method used to load dataframes from the input datasets list.

        If this is not the desired method, user should provide the decorator with their
        own data loading method. That method should have the similar signature to this default.

        Args:
            input_datasets (List[TabularDataset]): List of input datasets.
            cli_args (argparse.Namespace): The CLI arguments for this Pipeline step,
                passed by the decorator.

        Returns:
            List[pd.DataFrame]: a list of Pandas dataframe created by the input datasets,
                in the same order of the input datasets name list.
        """

        input_data = []
        for dataset in input_datasets:
            input_data.append(self.parse_dataset_to_step_input(dataset, cli_args))

        return input_data

    @typechecked
    def _register_output_as_dataset(self, outputs: Optional[Sequence[pd.DataFrame]],
                                    output_datasets: List[str],
                                    datastore: Any,
                                    cli_args: argparse.Namespace
                                    ) -> List[TabularDataset]:
        """The default method used to register the output dataframes as datasets to
        the given AML datastore. This method will register output data in the order
        indicated in otput_datasets, and it is expected to have the same number of
        output dataframes as the number of output datasets.
        If this method is not the desired method, user should provide the decorator
        their own register output method. The signature of that method should match
        this default method.

        Args:
            outputs (Optional[Sequence[pd.DataFrame]]): The list or the tuple of output dataframes.
            output_datasets (List[str]): The list of dataset named to register
                output dataframes with.
            datastore (Any): The datastore instance to register the datasets
            cli_args (argparse.Namespace): CLI arguments for the step.

        Returns:
            List[TabularDataset]: List of registered dataset instance.
        """

        registered_datasets = []

        if outputs is None:
            return registered_datasets

        validate_dataset_names(output_datasets)

        num_output_datasets = len(output_datasets)
        num_output_dataframes = len(outputs)
        if num_output_datasets != num_output_dataframes:
            raise ZendikonUserError(
                f"Number of expected output_datasets is different with number of returned output dataframes \n \
                Expected: {num_output_datasets}, Actual: {num_output_dataframes}."
            )

        # ! Warning: The method register_pandas_dataframe is experimenal. Refers to here:
        # https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.data.dataset_factory.tabulardatasetfactory?preserve-view=true&view=azure-ml-py#methods
        for ds_name, output_df in zip(output_datasets, outputs):
            registered_datasets.append(
                self.register_dataframe_as_dataset(output_df, self.OUTPUT_PATH_PREFIX, ds_name, datastore, cli_args)
            )

        return registered_datasets

    @staticmethod
    @typechecked
    def parse_dataset_to_step_input(input_dataset: TabularDataset,
                                    cli_args: argparse.Namespace) -> pd.DataFrame:  # pylint: disable=unused-argument
        """The method used to load dataframes from an input dataset.

        Args:
            input_dataset (TabularDataset): Input dataset
            cli_args (argparse.Namespace): The CLI arguments for this Pipeline step,
                passed by the decorator.

        Returns:
            pd.DataFrame: a Pandas dataframe created by the input dataset.
        """
        return input_dataset.to_pandas_dataframe()

    @staticmethod
    @typechecked
    def register_dataframe_as_dataset(dataframe: pd.DataFrame, ds_path: str,
                                      ds_name: str, datastore: Any,
                                      cli_args: argparse.Namespace) -> TabularDataset:  # pylint: disable=unused-argument
        """The method to register a pandas frame as a dataset on given AML workspace.

        Args:
            dataframe (pandas.DataFrame): The dataframe to be loaded into the dataset
            ds_path (str): The path to put the dataset in
            ds_name (str): The name under which to register the dataset in
            datastore (Any): The datastore to be associated with the registered dataset
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            TabularDataset: The resulting TabularDataset after registered on AML
        """
        return Dataset.Tabular.register_pandas_dataframe(
            dataframe, (datastore, ds_path+ds_name), ds_name)
