"""Module containing implementation of the AML Experiment config class
"""

import re
from typing import Any, Dict

from typeguard import typechecked


class ExperimentConfig():
    """Represents the configuration for the AML Experiment section in Zendikon config file.
    """
    EXPERIMENT_CONFIG_KEY: str = "experiment"
    EXPERIMENT_CONFIG_NAME_KEY: str = "name"

    @typechecked
    def __init__(self, config_dict: Dict[str, Any]) -> None:
        """Create an instance of ExperimentConfig from the config dictionary
        that contains parsed information from config YAML file.

        Args:
            config_dict (Dict[str, Any]): The dictionary containing parsed information from config YAML file.

        Raises:
            ValueError: raised when the experiment name does not follow AML requirements.
        """
        experiment_config_dict = config_dict[self.EXPERIMENT_CONFIG_KEY]

        self.name = experiment_config_dict[self.EXPERIMENT_CONFIG_NAME_KEY]

        # Validating the name following rule here:
        # https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.core.experiment.experiment?view=azure-ml-py#remarks
        if len(self.name) < 3 or len(self.name) > 36:
            raise ValueError("Experiment name must be 3-36 characters.")
        if not bool(re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9\-_]+", self.name)):
            raise ValueError(
                "Experiment name must start with a letter or a number, \
                and can only contain letters, numbers, underscores, and dashes.")
