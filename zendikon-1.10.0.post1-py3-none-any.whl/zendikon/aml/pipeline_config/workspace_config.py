"""Modules containing implementation of the AML workspace config class.
"""
import re
from typing import Any, Dict
from pathlib import Path

from typeguard import typechecked


class WorkspaceConfig():
    """Represents the configuration for the AML workspace.
    """

    WORKSPACE_CONFIG_KEY: str = "workspace"
    WORKSPACE_CONFIG_PATH_KEY: str = "config_path"
    COMPUTE_TARGET_CONFIG_KEY: str = "compute_target"
    DATASTORE_CONFIG_KEY: str = "datastore"

    @typechecked
    def __init__(self, config_dict: Dict[str, Any]) -> None:
        """Create a WorkspaceConfig instance from the config dictionary
        that contains parsed information from config YAML file.

        Args:
            config_dict (Dict[str, Any]): The dictionary containing parsed information from config YAML file.

        Raises:
            ValueError: raised if the path to config file does not exist or in bad form,
                or if the compute target name does not follow AML requirements.
        """
        ws_config_dict = config_dict[self.WORKSPACE_CONFIG_KEY]

        ws_config_str = ws_config_dict[self.WORKSPACE_CONFIG_PATH_KEY]
        if len(ws_config_str) == 0 or len(ws_config_str.strip()) == 0:
            raise ValueError(
                "The path to workspace config file cannot be empty.")

        self.workspace_config_path = Path(ws_config_str)
        self.compute_target = ws_config_dict[self.COMPUTE_TARGET_CONFIG_KEY]
        self.datastore = ws_config_dict[self.DATASTORE_CONFIG_KEY]

        if not self.workspace_config_path.exists():
            raise ValueError(
                f"The path to workspace config file does not exist: {self.workspace_config_path}")

        # AML cluster naming requirement: letters, digits, and - only
        if not bool(re.fullmatch(r"[a-zA-Z0-9\-]+", self.compute_target)):
            raise ValueError(
                "Compute target name can only contains letters, digits, and - character.")

        # Following rule from AML
        if not bool(re.fullmatch(r"[a-z0-9_]+", self.datastore)):
            raise ValueError(
                "Datastore name should only consist of lowercase letters, digits, and underscore")
