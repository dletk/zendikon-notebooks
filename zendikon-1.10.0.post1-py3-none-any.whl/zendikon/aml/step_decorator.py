"""
Implementation of the decorator for transfering a normal function to
be AML pipeline step compatible.
"""
import argparse
from abc import ABC, abstractmethod
from functools import wraps
from typing import Callable, Any, List, Optional, Sequence

from azureml.core.dataset import Dataset
from azureml.core.run import Run, _OfflineRun
from azureml.data.abstract_dataset import AbstractDataset
from azureml.exceptions import UserErrorException
from typeguard import typechecked

from zendikon.aml.utils import parse_arguments, get_argument_values_from_separated_string, validate_dataset_names
from zendikon.aml.exceptions import ZendikonInternalError, ZendikonUserError
from zendikon.aml.types import LoadInputType, RegisterOutputType, StepArgument


class AbstractAmlPythonStepCompatible(ABC):  # pylint: disable=too-few-public-methods
    """
    Abstract class to use as the base to create decorator for function that are supposed to be
    an AML pipeline Python step.
    Subclass of this abstract class will handle the work of reading pipeline parameters
    and input datasets for the given step. Then provide the steps with the actual value
    of input datasets.
    After the step script finished, it will register the output data to AML workspace for
    later usage.

    Step arguments will be pass as-is to the step function.
    """

    # The input dataset names and output path are passed in as CLI argument,
    # with value from config file and.
    NAMED_INPUT_DATASETS_ARG_NAME = "named_input_datasets"
    NAMED_INPUT_DATASETS_ARG = StepArgument(
        NAMED_INPUT_DATASETS_ARG_NAME,
        "List of named input datasets, comma-separated, in order",
        str,
        ""
    )

    NAMED_OUTPUT_DATASET_ARG_NAME = "named_output_datasets"
    NAMED_OUTPUT_DATASETS_ARG = StepArgument(
        NAMED_OUTPUT_DATASET_ARG_NAME,
        "List of named output datasets, comma-separated, in order",
        str,
        ""
    )

    OUTPUT_PATH_PREFIX = "step_output_data/"

    # This variable indicate if a decorated function is called from an inside of a decorated function
    # In this case, we should just call the function as it is and disable decorator's functionality
    _IS_INSIDE = False

    @typechecked
    def __init__(
        self, step_arguments: List[StepArgument] = None,
        load_inputs_func: LoadInputType = None,
        register_outputs_func: RegisterOutputType = None
    ) -> None:
        """Create a new instance of PythonStepCompatible decorator.
        This decorator will be called handled the work of reading input data and writing output data
        for the decorated function, make it compatible to be a PythonScriptStep in an
        AML pipeline. The decorated function must have a signature following this template::

            def function_name(<input_data1>, <input_data2>, ....,
                              cli_args: argsparse.Namespace = None,
                              run: aml.core.run = None) -> List[Any].
                cli_args: the Namespace from argument parser contain all CLI arguments
                run: the Run instance if this step is run on AML

        We ask the user to take the input data as first position arguments in the function. When running on AML,
        the input data will be provided by this decorator to the decorated function in the same order you specify
        in a config file.

        The rest of the arguments must be provided by user when calling the decorated function.
        Extra parameters can be added to the function, there is no limit on that.
        For offline run, the decorator has no effect to the function.
        Exact type of Any is defined in subclass.

        Example::

            @ZendikonDecoratorName
            def foo(features, targets, split_ratio=0.2, cli_args=None, run=None):
                ...

            foo(0.3)

        In this example, when running on AML, features, targets, args and run will be provided by the decorator.
        The split_ratio is an extra argument that you control when calling the function.

        Args:
            step_arguments (List[StepArgument], optional):
                List of CLI arguments we need to take in when running this decorated function.
                Defaults to None.
            load_inputs_func (Callable[ [argparse.Namespace, List[str]], List[Any] ], optional):
                The function to use for loading input data from the list of input dataset name.
                If None, a default function will be used.
                Defaults to None.
            register_outputs_func \
                (Callable[ [List[Any], List[str], Any, argparse.Namespace], List[Any] ], optional):
                The function to use for registering output data to the AML workspace.
                If none, a default function will be used.
                Defaults to None.
        """

        # Inject the CLI argument of input/output datasets to the step arguments list
        if step_arguments is None:
            step_arguments = []
        step_arguments += [
            self.NAMED_INPUT_DATASETS_ARG,
            self.NAMED_OUTPUT_DATASETS_ARG
        ]
        self.step_arguments = step_arguments

        self.load_inputs_func = load_inputs_func or self._load_input_data

        self.register_outputs_func = register_outputs_func or self._register_output_as_dataset

        self.aml_run = Run.get_context()
        if isinstance(self.aml_run, _OfflineRun):
            self.aml_ws = None
            self.aml_experiment = None
            self.is_offline_run = True
        else:
            self.aml_ws = self.aml_run.experiment.workspace
            self.aml_experiment = self.aml_run.experiment
            self.is_offline_run = False

        self.cli_arguments = None
        self.input_dataset_names = None
        self.output_dataset_names = None

    @typechecked
    def __call__(self, function: Callable) -> Callable:
        """Method to be called as a wrapper to the decorated function, handling groundwork for
        AML pipeline step such as reading datasets, reading CLI arguments, as well as handling
        the returned results.

        Args:
            function (Callable): The function performing the actual tasks in this pipeline step,
                decorated by this method. This function must have the template::

                    def function_name(<input_data1>, <input_data2>, ....,
                                    cli_args: argsparse.Namespace = None,
                                    run: aml.core.run = None) -> List[Any].
                        cli_args: the Namespace from argument parser contain all CLI arguments
                        run: the Run instance if this step is run on AML

            We ask you to keep the input data at the STARTING POSITIONS. When running on AML, the input data
            will be provided by this decorator to the decorated function IN THE SAME ORDER you specify
            in a config file.

            The rest of the arguments must be provided when calling the decorated function.
            For offline run, the decorator has NO effect to the function.
        Returns:
            Any: The return value of the decorated function.
        """
        @wraps(function)
        def wrapped(*args, **kwargs):
            if self.is_offline_run:
                script_result = function(*args, **kwargs)

                return script_result

            # ======= AML run ==========
            self.cli_arguments = parse_arguments(self.step_arguments)
            try:
                self.input_dataset_names = get_argument_values_from_separated_string(
                    self.NAMED_INPUT_DATASETS_ARG_NAME, self.cli_arguments)
                self.output_dataset_names = get_argument_values_from_separated_string(
                    self.NAMED_OUTPUT_DATASET_ARG_NAME, self.cli_arguments)
            except KeyError as keyerr:
                error_message = "CLI arguments namespace does not contains required input and output arguments, \
                                decorator internal error \
                                failing the run!"
                self.aml_run.fail(error_details=error_message)
                raise ZendikonInternalError from keyerr

            try:
                #! Notice: Empty list is a valid option
                # in that case, user doesn't need inputdatasets or does not want to register any output.
                validate_dataset_names(self.input_dataset_names)
                validate_dataset_names(self.output_dataset_names)
            except ValueError as val_err:
                error_message = "Invalid dataset name provided."
                self.aml_run.fail(error_details=error_message)
                raise ZendikonUserError from val_err

            input_data = self.load_inputs_func(
                self.cli_arguments, self.input_dataset_names)

            if not isinstance(input_data, list):
                raise ZendikonUserError(
                    f"The expected return type for load input function is a list, got: {type(input_data)}")

            args = input_data + list(args)
            kwargs["cli_args"] = self.cli_arguments
            kwargs["run"] = self.aml_run

            script_result = function(*args, **kwargs)

            if script_result is not None and not isinstance(script_result, (list, tuple)):
                script_result = (script_result, )

            self.register_outputs_func(
                script_result,
                self.output_dataset_names,
                self.aml_ws.get_default_datastore(),
                self.cli_arguments
            )

            return script_result

        @wraps(function)
        def _inside_guard(*args, **kwargs):
            """
            This function sets the _IS_INSIDE flag and ensures that _IS_INSIDE flag is reset on exiting from the
            top-level decorated function.
            """
            need_reset_is_inside = False
            is_top_level_function = not AbstractAmlPythonStepCompatible._IS_INSIDE
            if is_top_level_function:
                AbstractAmlPythonStepCompatible._IS_INSIDE = True
                need_reset_is_inside = True

            try:
                if not is_top_level_function:
                    # setting is_offline_run to True will disable all AML functionality
                    self.is_offline_run = True

                result = wrapped(*args, **kwargs)
            finally:
                if need_reset_is_inside:
                    AbstractAmlPythonStepCompatible._IS_INSIDE = False

            return result

        return _inside_guard

    @typechecked
    def _load_input_data(self, cli_args: argparse.Namespace, dataset_names: List[str]) -> List[Any]:
        """The default method used to load input_data from the input dataset names.
        If this is not the desired method, user should provide the decorator with their
        own data loading method. That method should have the similar signature to the default
        one that they are replacing.

        Args:
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.
            dataset_names (List[str]): List of input dataset names for the step.

        Returns:
            List[Any]: List of parsed data from datasets (dataframes, file,...)
        """

        validate_dataset_names(dataset_names)
        datasets = self._load_datasets_by_name(dataset_names)
        input_data = self._parse_datasets_to_step_input(datasets, cli_args)

        return input_data

    @typechecked
    def _load_datasets_by_name(self, dataset_names: List[str]) -> List[AbstractDataset]:
        """
        Find and load required datasets. This method will loads datasets using the input_datasets property of Run class,
        or registered datasets in the AML workspace, in that order.

        Args:
            dataset_names (List[str]): List of input datasets name.

        Returns:
            List[AbstractDataset]: a list of datasets, can be either of a list of
                TabularDataset or FileDataset, or mixture of them, depends on which decorator is used.
        """

        input_data = []

        validate_dataset_names(dataset_names)

        for ds_name in dataset_names:
            try:
                dataset = self.aml_run.input_datasets[ds_name]
            except KeyError as key_err:
                print(key_err)
                error_message = f"There is no input dataset named: {ds_name}, \
                                trying with workspace registered datasets..."
                print(error_message)

                try:
                    dataset = Dataset.get_by_name(self.aml_ws, name=ds_name)
                except UserErrorException as user_err:
                    print(user_err.print_stacktrace())
                    print(user_err)

                    error_message = f"There is no registered dataset named: {ds_name}, \
                                    failing the run!"
                    self.aml_run.fail(error_details=error_message)
                    raise ZendikonUserError from None
            input_data.append(dataset)

        return input_data

    @abstractmethod
    def _parse_datasets_to_step_input(self,
                                      input_datasets: List[AbstractDataset], cli_args: argparse.Namespace
                                      ) -> List[Any]:
        """Method to convert the datasets from AML to actual input data for the pipeline step.
        This list of input datasets is obtained by other helper methods in the decorator.

        Args:
            input_datasets (List[AbstractDataset]): List of datasets to parse.
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[Any]: List of parsed data from datasets (dataframe, files,...)
        """
        ...

    @abstractmethod
    def _register_output_as_dataset(self, outputs: Optional[Sequence[Any]],
                                    output_datasets: List[str],
                                    datastore: Any,
                                    cli_args: argparse.Namespace
                                    ) -> List[Any]:
        """The default method used to register the output of this step to
        datasets. If this is not the desired method, user should provide the
        decorator with their own registering method. That method should have
        similar signature to the default one that they are replacing.

        Args:
            outputs (Sequence[Any]): The list or the tuple of output data to register to the Workspace datastore.
            output_datasets (List[str]): Names of datasets to register these output data.
            datastore (Any): The Datastore instance from AML Workspace
            cli_args (argparse.Namespace): The CLI arguments namespace for this pipeline step.

        Returns:
            List[Any]: List of registered dataset reference (AbstractDataset/TabularDataset...)
        """
        ...
