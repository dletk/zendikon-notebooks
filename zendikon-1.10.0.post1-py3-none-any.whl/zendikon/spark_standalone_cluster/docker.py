"""
Module containing functions used to spin-up/down the Spark Standalone Cluster.
"""
import os
import stat
import itertools
import logging
import subprocess  # nosec: TODO: [7297] use docker package for container/image mgmt
import contextlib
import signal
from typing import Set, List
from enum import Enum

import docker
from dotenv import load_dotenv

from zendikon.utils.network import check_port


class PortFromConfig(Enum):
    """ An enumeration that defines the set of ports to load from the environment"""
    SPARK_MASTER = "PORT_SPARK_MASTER"
    SPARK_MASTER_UI = "PORT_WEB_UI_SPARK_MASTER"
    HADOOP_NAMENODE_UI = "PORT_WEB_UI_HADOOP_NAMENODE"
    HADOOP_RES_MANAGER_UI = "PORT_WEB_UI_HADOOP_RES_MANAGER"
    HADOOP_JOB_HISTORY_UI = "PORT_WEB_UI_HADOOP_JOB_HISTORY"
    HADOOP_NAMENODE = "PORT_HADOOP_NAMENODE"


class PortRangeFromConfig(Enum):
    """ An enumeration that defines the set of port ranges to load from the environment """
    SPARK_WORKERS_UI = "PORT_RANGE_WEB_UI_SPARK_WORKERS"


DIR = os.path.dirname(os.path.abspath(__file__))
BUILD_SCRIPT = os.path.join(DIR, "build-images.sh")
ENV_FILE = os.path.join(DIR, ".env")
IMG_DIR = os.path.join(DIR, "docker")
REQUIRED_PORT_NAMES = [p.value for p in PortFromConfig]
REQUIRED_PORT_RANGES = [pr.value for pr in PortRangeFromConfig]

logger = logging.getLogger(__name__)


def create_images() -> bool:
    """
    Creates Docker images required by the Spark Standalone Cluster.

    Returns:
        bool: True if the images have been created successfully, false otherwise.
    """
    logger.info("Docker build script located: %s", BUILD_SCRIPT)

    perms = os.stat(BUILD_SCRIPT).st_mode
    os.chmod(BUILD_SCRIPT, perms | stat.S_IXUSR)
    process = subprocess.Popen(  # nosec: subprocess input is managed
        ["bash", BUILD_SCRIPT],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        cwd=DIR,
    )

    while process.poll() is None:
        line = process.stdout.readline()
        print(line.strip())

    logger.info("Docker build script returned with status: %d", process.returncode)

    if process.returncode != 0:
        print("Failed to build Docker images for Spark Standalone Cluster.")
        logger.error(process.stderr)
        return False

    print("Successfully built Docker images for Spark Standalone Cluster.")
    return True


def check_images_created() -> bool:
    """
    Checks to see if the Docker images for the Spark Standalone Cluster have been created
    successfully.

    Returns:
        bool: True if the images have been created successfully, false otherwise.
    """
    _set_env()
    image_tags = _get_image_tags(from_containers=False)
    cluster_tags = _get_cluster_tag_names()
    missing_tags = cluster_tags.difference(image_tags)

    if len(missing_tags) > 0:
        print(
            "Failed to find the following Docker images:"
            f" {', '.join(str(tag) for tag in missing_tags)}"
        )
        print("Try running the `zendikon new docker-spark-cluster command.")
        return False

    return True


def spin_up_containers(workers: int, detach: bool) -> bool:
    """
    Spins up Docker containers for the Spark Standalone Cluster from preexisting images.

    Args:
        workers (int): The number of Spark worker nodes to create in the cluster.
        detach (bool): If true the process will spin-up the containers and detach from
            the Docker Compose process and return a message to the user. If false, the
            process will stay attached and display the cluster logs in real-time in
            stdout.

    Raises:
        RuntimeError: Attempt to spin-up cluster with more than two Spark worker nodes.
        RuntimeError: Ports required by the cluster are currently in use.

    Returns:
        bool: True if the cluster containers have successfully spun-up, false otherwise.
    """
    _set_env()
    configs = [(var, os.getenv(var)) for var in REQUIRED_PORT_NAMES + REQUIRED_PORT_RANGES]
    if not all(list(zip(*configs))[1]):
        undefined_var = [var for (var, value) in configs if value is None]
        logger.error("Undefined environment var needed by cluster: %s", undefined_var)
        raise RuntimeError(
            f"The Zendikon Spark Standalone Cluster needs these ENV Variables defined: {undefined_var}. "
            f"Please edit {ENV_FILE}."
        )

    spark_worker_ui_port_range = os.getenv(PortRangeFromConfig.SPARK_WORKERS_UI.value)
    spark_worker_ui_ports = _parse_port_range(spark_worker_ui_port_range)

    if workers > len(spark_worker_ui_ports):
        logger.error("Attempt to spin-up more workers than currently supported.")
        raise RuntimeError(
            f"Attempting to launch more Spark worker nodes ({workers}) than "
            f"the allocated port range: {spark_worker_ui_port_range} ({len(spark_worker_ui_ports)})\n"
            f"Please edit '{PortRangeFromConfig.SPARK_WORKERS_UI.value}' in {ENV_FILE}"
        )
    if _check_containers_running():
        logger.info("Spark Standalone Cluster containers are already running.")
        print("The Spark Standalone Cluster is already up and running.")
        return True

    ports = [int(os.getenv(port_name)) for port_name in REQUIRED_PORT_NAMES]
    port_ranges_2d = [_parse_port_range(os.getenv(p_range)) for p_range in REQUIRED_PORT_RANGES]
    port_ranges_flatten = list(itertools.chain(*port_ranges_2d))
    ports += port_ranges_flatten
    avail_ports = [(port, check_port(port)) for port in ports]
    logger.info("Port status: %s", avail_ports)

    if not all(list(zip(*avail_ports))[1]):
        in_use = [port for (port, available) in avail_ports if not available]
        logger.error("Ports needed by cluster in use: %s", in_use)
        raise RuntimeError(
            "The Zendikon Spark Standalone Cluster needs these ports to be free in"
            f" order to run: {in_use}"
        )

    logger.info(
        "Spinning-up containers with %d workers and detach mode %s.",
        workers,
        "enabled" if detach else "disabled",
    )

    _exit_handler()

    args = ["docker-compose", "up", "--scale", f"spark-worker={workers}"]
    args = args + ["--detach"] if detach else args
    logger.info("Calling subprocess with args: %s", args)

    process = subprocess.Popen(  # nosec: subprocess input is managed
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        cwd=DIR,
    )

    while process.poll() is None:
        line = process.stdout.readline()
        print(line.strip())

    logger.info("Docker Compose returned with status: %d", process.returncode)

    if process.returncode != 0:
        print("Failed to spin-up Docker containers for Spark Standalone Cluster.")
        logger.error(process.stderr)
        return False

    print("Successfully spun-up Docker containers for Spark Standalone Cluster.")
    return True


def spin_down_containers(*_args, **_kwargs) -> bool:
    """
    Spins-down any running Docker containers for the Spark Standalone Cluster.

    Returns:
        bool: True if the containers have been spun-down, false otherwise.
    """
    if not _check_containers_running():
        logger.info("No Docker containers to spin-down.")
        print("The Spark Standalone Cluster is not currently running.")
        return True

    logger.info("Spinning-down Docker containers.")
    process = subprocess.Popen(  # nosec: subprocess input is managed
        ["docker-compose", "down"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        cwd=DIR,
    )

    while process.poll() is None:
        line = process.stdout.readline()
        print(line.strip())

    if process.returncode != 0:
        print("Failed to spin-down Docker containers for Spark Standalone Cluster.")
        logger.error(process.stderr)
        return False

    print("Successfully spun-down Docker containers for Spark Standalone Cluster.")
    return True


def _exit_handler() -> None:
    """
    In case of an unexpected terminal signal during the Spark Standalone Cluster creation
    process, this will spin-down the cluster containers so that they aren't unnecessarily
    running.
    """
    logger.info("Setting up exit handler.")
    signal.signal(signal.SIGTERM, spin_down_containers)
    signal.signal(signal.SIGINT, spin_down_containers)


def _set_env() -> None:
    """
    Sets environment variables required by the Spark Standalone Cluster.
    """
    logger.info("Docker build script located: %s", BUILD_SCRIPT)
    logger.info("Spark Standalone cluster .env file located: %s", ENV_FILE)

    # The build script has variables in it that we need but is not a true env file
    # so `load_dotenv` will print a bunch of warnings, this will suppress them.
    with open(os.devnull, "w") as devnull:
        with contextlib.redirect_stderr(devnull):
            load_dotenv(ENV_FILE)
            load_dotenv(BUILD_SCRIPT)

    logger.info("Spark Standalone Cluster environment variables set.")


def _get_image_tags(from_containers: bool = False) -> Set[str]:
    """
    Gets Docker all Docker image tags that are accessible in the current environment.

    Args:
        from_containers (bool, optional): If true, this will extract the image tag names
            out of the result of the `docker container ls` command. If false, this will
            extract the image tag names out of the result of the `docker image ls` command.
            Defaults to False.

    Returns:
        Set[str]: the Docker image tag names.
    """
    docker_client = docker.from_env()
    img_src = (
        docker_client.images.list()
        if not from_containers
        else [container.image for container in docker_client.containers.list()]
    )

    image_tags = [img.tags[0] for img in img_src if img.tags]
    logger.info(
        "Found the following Docker %s image tags: %s",
        "container" if from_containers else "",
        image_tags,
    )

    return set(image_tags)


def _get_cluster_tag_names() -> Set[str]:
    """
    Gets all Docker image tag names that will be in the Spark Standalone Cluster.

    Returns:
        Set[str]: The Docker image tag names.
    """
    _set_env()
    tag_prefixes = os.listdir(IMG_DIR)
    tag_suffix = os.environ["BASE_IMAGE_VERSION"]  # set in `build-images.sh`
    logger.info("Docker image tag suffix: %s", tag_suffix)

    tags = {f"{tag_prefix}:{tag_suffix}" for tag_prefix in tag_prefixes}
    logger.info(
        "Found the following Docker image tag names for the Spark Standalone"
        " Cluster: %s",
        tags,
    )

    return tags


def _check_containers_running() -> bool:
    """
    Checks to see if all the Docker containers required by the Spark Standalone Cluster
    are running.

    Returns:
        bool: True if all the required containers are running, false otherwise.
    """
    image_tags = _get_image_tags(from_containers=True)
    cluster_tags = _get_cluster_tag_names()

    if cluster_tags.isdisjoint(image_tags):
        logger.info("Spark Standalone Cluster containers are not running")
        return False

    logger.info("Spark Standalone Cluster containers are running")
    return True

def _parse_port_range(port_range: str) -> List[int]:
    """ Parse a port range "p1-p2" and return as a list of port numbers

    Args:
        port_range (str): a port range string ("p1-p2")

    Returns:
        a list of port numbers in the port range
    """
    try:
        low, high = port_range.split("-")
        ports = list(range(int(low), int(high)+1)) # +1 b/c range is not inclusive
    except ValueError as error:
        raise ValueError(f"Invalid port range: '{port_range}'. Expected format: 'p1-p2'") from error
    except TypeError as error:
        raise ValueError(f"Invalid port range: '{port_range}'. Expected format: 'p1-p2'") from error
    return ports
