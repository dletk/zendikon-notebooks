# SOURCE REFERENCE: https://github.com/mvillarrealb/docker-spark-cluster/tree/master/docker/spark-worker

#!/bin/bash
# startup script to be used in the spark-worker container

# Start ssh service for hadoop networking
service ssh start

# Start Hadoop DFS
$HADOOP_HOME/sbin/start-dfs.sh
$HADOOP_HOME/sbin/start-yarn.sh

. "$SPARK_HOME/sbin/spark-config.sh"
. "$SPARK_HOME/bin/load-spark-env.sh"

mkdir -p $SPARK_WORKER_LOG

export SPARK_HOME=/spark
# Extra configurations for "Hadoop Free" build for Spark
# Please see https://spark.apache.org/docs/2.4.4/hadoop-provided.html
# And explanation in https://stackoverflow.com/questions/39943628/the-difference-between-a-hadoop-installed-by-standalone-and-a-hadoop-included-in
export SPARK_DIST_CLASSPATH=$($HADOOP_HOME/bin/hadoop classpath)

ln -sf /dev/stdout $SPARK_WORKER_LOG/spark-worker.out

/spark/bin/spark-class org.apache.spark.deploy.worker.Worker \
--webui-port $SPARK_WORKER_WEBUI_PORT $SPARK_MASTER >> $SPARK_WORKER_LOG/spark-worker.out