# Setting Up a Standalone Spark Cluster (via Docker Containers)

![standalone cluster](../../../docs/img/standalone_cluster.png =800x)

Reference: https://github.com/mvillarrealb/docker-spark-cluster

## Table of Contents
[[_TOC_]]

## Introduction
Development with Spark application isn't easy, especially when it comes to testing. Often times testing in the "local" mode is not enough, because it does not simulate an cluster in deployment. For local testing and CI/CD purpose, we can launch a Spark cluster in [Standalone Mode](https://spark.apache.org/docs/latest/spark-standalone.html) via Docker and Docker Compose.

## Prerequisites
To setup a Standalone Spark Cluster in your local machine, you will need to have installed:
1. [Docker](https://docs.docker.com/get-docker/)
2. [Docker Compose](https://docs.docker.com/compose/install/) (you can also install docker-compose via pip: `pip install docker-compose`)
3. Follow this [guide so you can run `docker` and `docker-compose` without being a root user (i.e. `sudo docker`)](https://docs.docker.com/engine/install/linux-postinstall/#manage-docker-as-a-non-root-user)
4. You have `zendikon[spark-standalone-cluster]` installed. If not, run:

    `pip install zendikon[spark-standalone-cluster] --index-url=https://pkgs.dev.azure.com/MAIDAP/Zendikon/_packaging/maidap-zendikon/pypi/simple/`

**NOTE:** if you are using Docker for Windows and WSL2, please see [below](#wsl2-and-docker-for-windows) for extra setup.

**TODO:** add support for Windows setup

## TLDR
To run the Standalone Spark Cluster:
```sh
zendikon spark-standalone-cluster create
zendikon spark-standalone-cluster start
```
To connect to the cluster and read from HDFS:

```py
from pyspark import SparkFiles
from pyspark.sql import SparkSession # Please ensure you installed a version of pyspark equal to that running in the cluster

spark = SparkSession.builder.master("spark://localhost:7077").getOrCreate()
spark.sparkContext.addFile("hdfs://localhost:9000/user/root/artifacts/helloworld.txt")
f = SparkFiles.get("helloworld.txt")
print(open(f).read())
```

To stop:
```sh
zendikon spark-standalone-cluster stop
```

**NOTE**: Please ensure that your pyspark version is same as the version of spark in the cluster (EX: `pip install pyspark==3.1.1`)

**NOTE:** Assuming the default configuration, you can check the status of the cluster via the web UI:
  - Spark Master Node: [http://localhost:8080](http://localhost:8080)
  - Hadoop Namenode: [http://localhost:9870](http://localhost:9870)
  - Hadoop Resource Manager: [http://localhost:8088](http://localhost:8088)

## Build the Images
We begin by building the docker images defined by a `Dockerfile`:

```sh
chmod +x build-images.sh
./build-images.sh
```

This will create the following images:
1. `base`: A base image based on `python:3.6-buster` which will be consumed other dependent images. This image has the followings installed (you can change the versions of these in [`.env`](./.env):
    - Spark
    - Hadoop
    - Python
    - Java
    - Sbt
1. `hadoop-config`: An image based on `base` and is used to configure the Hadoop Distributed File System in the [cluster mode](https://hadoop.apache.org/docs/r2.7.7/hadoop-project-dist/hadoop-common/ClusterSetup.html).
1. `spark-master`: An image based on `hadoop-config` and is used to serve a spark master node **as well as** HDFS namenode.
1. `spark-worker`: An image based on `hadoop-config` and is used to create multiple spark worker nodes **as well as** HDFS datanode.
1. `hdfs-upload`: An image based on `hadoop-config` and is used to submit files (e.g. model artifacts) into the HDFS cluster. The HDFS cluster must be alive before executing this docker image.

**NOTE:** that the files included in the build context for all these docker images are specified in [../../.dockerignore](../../.dockerignore)

## Run docker-compose
**PREREQUISITE**: If you haven't done so already, follow this [guide so you can run `docker` and `docker-compose` without being a root user (i.e. `sudo docker`)](https://docs.docker.com/engine/install/linux-postinstall/#manage-docker-as-a-non-root-user)

You can spin up your standalone cluster by running:

```sh
docker-compose up --scale spark-worker=2
```

**NOTE** Our test will consume the env var `SPARK_MASTER_IP` to connect to the cluster. Modify this env var accordingly.

**NOTE**: that we are spinning up 2 worker nodes for the minimal parallelism. If you want to spin up more worker nodes, you will also need to expand the port ranges for the worker node container to run on in [docker-compose.yml](docker-compose.yml) as follow:

```yml
  spark-worker:
    image: spark-worker:${SPARK_VERSION}-hadoop${HADOOP_VERSION}
    ports:
      # Allocating wider port range than what's needed can induce this issue described in:
      # https://github.com/docker/compose/issues/722#issuecomment-448207981
      - "8081-8082:8081" # for 2 worker nodes <--------------------------------
```

**DEBUGGING**: If you encountered the error `Cannot start service spark-worker: driver failed programming external connectivity on endpoint ... : all ports are allocated`, please refer to the note above.

By default `docker-compose` will pick up the environment variables defined in  [`.env`](./.env) these variables include:

```sh
# Built-time config for `base` Dockerfile
JAVA_VERSION=8
SPARK_VERSION=3.1.1
HADOOP_VERSION=2.7
SBT_VERSION=1.2.8
PY_VERSION=3.6

# Runtime config consumed by docker-compose
SPARK_MASTER_IP=172.28.0.2
SPARK_DAEMON_MEMORY=2G
SPARK_WORKER_CORES=1
SPARK_WORKER_MEMORY=1G
```

You can change the configs in the [`.env`](./.env) file or overwrite these environment variables at runtime. Note that the driver runs on the default port `7070`. To add other configurations via environment variables, please see [doc.](https://spark.apache.org/docs/2.1.1/spark-standalone.html)

## Validate the Cluster
Assuming the default configuration, you can check the status of the cluster via the web UI:
- Spark Master Node: [http://localhost:8080](http://localhost:8080)
- Hadoop Namenode: [http://localhost:9870](http://localhost:9870)
- Hadoop Resource Manager: [http://localhost:8088](http://localhost:8088)

Or if you don't have access to a browser, just `curl http://localhost:8080` to get the html, for example.

You can browse the files auto-populated onto the  HDFS via the Hadoop Namenode web UI [http://localhost:9870](http://localhost:9870).

To **further** validate the functionality of the Hadoop cluster, in a separate terminal, run the following commands:

```bash
docker exec -it spark_standalone_cluster_spark-master_1 bash
. ~/run-wordcount.sh
```

The above commands will submit a job to the HDFS counting the words from 2 dummy files.

## Connect to the Spark Cluster in Pyspark
To connect the standalone cluster we just created, assuming you have `pyspark` installed, you can run the following on your machine (which host the docker containers):

```py
from pyspark.sql import SparkSession
spark = SparkSession.builder.master("spark://localhost:7077").getOrCreate()
```

## Consume HDFS filepaths in Pyspark
Note that the files in `artifacts/` will be automatically populated into the HDFS under the path `hdfs://localhost:9000/user/root/artifacts/`, you can run the followings to load them into Spark context.

```py
from pyspark import SparkFiles
from pyspark.sql import SparkSession

spark = SparkSession.builder.master("spark://localhost:7077").getOrCreate()
spark.sparkContext.addFile("hdfs://localhost:9000/user/root/artifacts/helloworld.txt")
f = SparkFiles.get("helloworld.txt")
print(open(f).read())
```

## WSL2 and Docker for Windows

Currently, with Docker for Windows you cannot access Linux containers by private IP from the host, even if you enable the WSL2 distro support (see this [GitHub thread](https://github.com/docker/for-win/issues/6610) for more info). This will pose a problem for connecting to the spark cluster because their container IPs is no longer reachable outside the docker network. If you are using WSL2, please **disable** the Docker for Windows WSL2 distro support and install docker as you would in any linux distribution [following the doc](https://docs.docker.com/engine/install/ubuntu/).