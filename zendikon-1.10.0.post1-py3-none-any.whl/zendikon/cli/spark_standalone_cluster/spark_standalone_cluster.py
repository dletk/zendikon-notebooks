"""
Module managing the `spark-standalone-cluster` CLI command group.
"""
import click

from zendikon.cli.spark_standalone_cluster.create import create_spark_standalone_cluster
from zendikon.cli.spark_standalone_cluster.start import start_spark_standalone_cluster
from zendikon.cli.spark_standalone_cluster.stop import stop_spark_standalone_cluster


@click.group("spark-standalone-cluster")
def spark_standalone_cluster_command_group():
    """
    Command group to manage Zendikon Spark Standalone Cluster resource (requires
    additional subcommands).
    """


spark_standalone_cluster_command_group.add_command(create_spark_standalone_cluster)
spark_standalone_cluster_command_group.add_command(start_spark_standalone_cluster)
spark_standalone_cluster_command_group.add_command(stop_spark_standalone_cluster)
