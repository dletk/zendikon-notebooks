"""CLI for generating AML pipeline code.
"""
from pathlib import Path

import click

from zendikon.aml.pipeline_config.driver_code import (
    generate_driver_code, _PIPELINE_TEMPLATE_DIR, _PIPELINE_TEMPLATE_FILENAME
)


@click.command("generate-pipeline")
@click.option(
    "--pipeline-config",
    type=str,
    required=True,
    help="Path to the pipeline config YML file.")
@click.option(
    "--output-file",
    type=str,
    required=True,
    help="Output file name to save the generated code."
)
@click.option(
    "--template-dir",
    type=str,
    default=_PIPELINE_TEMPLATE_DIR,
    show_default=True,
    help="(Advanced feature) Folder containing the Jinjia template file for AML pipeline driver code."
)
@click.option(
    "--template-file",
    type=str,
    default=_PIPELINE_TEMPLATE_FILENAME,
    show_default=True,
    help="(Advanced feature) The Jinjia template file for AML pipeline driver code."
)
def generate_pipeline(pipeline_config: str, output_file: str, template_dir: str, template_file: str):
    """Subcommand to generate AML pipeline driver code from the given template file and YAML config.
    """
    generate_driver_code(Path(pipeline_config), Path(output_file), Path(template_dir), template_file)
