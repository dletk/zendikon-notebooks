"""Module containing implementation of the Reusable pipeline class and other supporting classes.
"""

from collections import defaultdict
from typing import Any, Callable, DefaultDict, Dict, List, Sequence, Tuple, Type

from azureml.core import ComputeTarget, Experiment, Run
from azureml.pipeline.core import Pipeline as AmlPipeline
from azureml.pipeline.core import PipelineStep, PipelineData
from typeguard import typechecked

from zendikon.aml.utils import validate_dataset_names
from zendikon.pipelines._pipeline_step_info import PipelineStepInfo
from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig
from zendikon.pipelines.utils import validate_steps_info


class Pipeline:
    """The class represents an ML pipeline created using Zendikon.
    """

    @typechecked
    def __init__(self, input_datasets: Sequence[str],
                 compute_targets: List[ComputeTarget],
                 steps_info: List[PipelineStepInfo],
                 step_factory: Callable[[Type[BasePipelineStep], StepConfig], BasePipelineStep] = None) -> None:
        """Create an instance of pipeline with Zendikon.

        Args:
            input_datasets (Sequence[str]): Names of the input datasets of the pipeline.
                Empty sequence is valid input. It means the pipeline does not start with a registered dataset.
            compute_targets (List[ComputeTarget]): List of 1 or more Compute target instances to run the pipeline.
                The compute targets are currently utilized by the steps in the order in which they are specified.
                If len(compute_targets) > #steps, some compute targets at the ends of the list may not be utilized.
                If len(compute_targets) == #steps, all compute targets will be utilized with exactly 1 step.
                If len(compute_targets) < #steps, the compute targets at the start of the list may be utilized more.
            steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.
            step_factory (Callable[[Type[BasePipelineStep], StepConfig], BasePipelineStep], optional): Function to be
                used for creating a new instance of BasePipelineStep. This allows user to control how to create
                instances of different reusable step classes they have in their pipeline.
                Leave it as None to use the default function.
                Defaults to None.

        Raises:
            ValueError: If no ComputeTarget objects are specified, if steps_info is an empty list,
                or if input dataset names have invalid characters.
        """
        if len(compute_targets) == 0:
            raise ValueError("No ComputeTarget objects specified.")
        self.compute_targets = compute_targets

        validate_steps_info(steps_info)
        self._steps_info: List[PipelineStepInfo] = steps_info

        # Add the pipeline input dataset to list of first step input datasets.
        # pipeline_input_datasets is a List passed by reference (Python standard), we are modifying it in-place here.
        pipeline_input_datasets = self._steps_info[0].step_config.inputs
        validate_dataset_names(input_datasets)
        for dataset_name in input_datasets:
            if dataset_name not in pipeline_input_datasets:
                pipeline_input_datasets.append(dataset_name)

        self._steps = None

        self.step_factory = step_factory if step_factory else self._default_step_factory

        self._step_dependencies, self._leaf_steps = self._get_step_dependency_graph()


    @property
    def steps_info(self) -> List[PipelineStepInfo]:
        """Property to return the current list of step info of this pipeline.

        Returns:
            List[PipelineStepInfo]: A copy of current step info list.
        """
        return self._steps_info[:]

    @steps_info.setter
    @typechecked
    def steps_info(self, value: List[PipelineStepInfo]):
        """Setting the value of step info of this pipeline.
        Setting this value will also reset the steps instances associated with this pipeline.

        Args:
            value (List[PipelineStepInfo]): The new list step info.

        Raises:
            ValueError: Raised if value is an empty list.
        """
        validate_steps_info(value)
        self._steps_info = value

        self._step_dependencies, self._leaf_steps = self._get_step_dependency_graph()

        self._steps = self._create_pipeline_steps(self.compute_targets)

    @property
    def steps(self) -> List[PipelineStep]:
        """Property for accessing list of steps in this pipeline.

        Returns:
            List[PipelineStep]: The list of PipelineStep instances used for this pipeline.
        """
        # First time getting steps will create the steps.
        if self._steps is None:
            self._steps = self._create_pipeline_steps(self.compute_targets)
        return self._steps[:]

    @typechecked
    def submit(self, experiment: Experiment,  # pylint: disable=too-many-arguments
               pipeline_parameters: Dict[str, Any] = None,
               wait_for_completion=False,
               add_zendikon_feed: bool = False, personal_access_token: str = None) -> Run:
        """Method to submit the pipeline to AML for execution.
        The pipeline is created using Zendikon package, so it will need to authenticate to Zendikon Pip feed to install
        the package when creating the pipeline docker image.

        Args:
            experiment (Experiment): The experiment instance to submit this pipeline to.
            pipeline_parameters (Dict[str, Any], optional): Pipeline parameters and values
                to add to the pipeline.
                Defaulted to None.
            wait_for_completion (bool, optional): Whether to wait for the pipeline to finish.
                Setting this option will be blocking your workflow.
                Defaults to False.
            add_zendikon_feed (bool, optional): Whether to add PAT to authenticate to Zendikon feed.
                This only needs to happen once per AML Workspace.
                Defaults to False.
            personal_access_token ([type], optional): The token to authenticate to Zendikon Pip feed.
                Defaults to None.

        Returns:
            Run: The run instance of the pipeline.
        """

        workspace = experiment.workspace

        if add_zendikon_feed:
            if personal_access_token is None:
                raise ValueError("Personal access token cannot be None if add_zendikon_feed is True. Must be a string.")

            # Set the personal access token for the workspace to access Zendikon Pip feed
            pat_token = personal_access_token
            workspace.set_connection(name="PAT for installing Zendikon",
                                     category="PythonFeed",
                                     target="https://pkgs.dev.azure.com",
                                     authType="PAT",
                                     value=pat_token)

        pipeline = AmlPipeline(workspace, steps=self.steps)
        if pipeline_parameters is not None:
            run = experiment.submit(
                pipeline, pipeline_parameters=pipeline_parameters)
        else:
            run = experiment.submit(pipeline)
        if wait_for_completion:
            run.wait_for_completion(show_output=True)

        return run

    @classmethod
    def _default_step_factory(cls, step_class: Type[BasePipelineStep], step_config: StepConfig) -> BasePipelineStep:
        """Default function to be used for creating a new BasePipelineStep instance from provided step_config
        and given the class to initialized the instance with.

        Args:
            step_class (Type[BasePipelineStep]): The class to initialized the step instance with.
            step_config (StepConfig): the step configuration to create the instance.

        Returns:
            BasePipelineStep: The instance of reusable step.
        """
        return step_class(step_config)

    def _get_step_dependency_graph(self) -> Tuple[DefaultDict[BasePipelineStep, List[BasePipelineStep]],
                                                  List[BasePipelineStep]]:
        """Helper method to get the step dependency mapping.

        Returns:
            DefaultDict[BasePipelineStep, List[BasePipelineStep]]: The mapping between a BasePipelineStep object
                and a list of its immediate prerequisite steps.
            List[BasePipelineStep]: List of BasePipelineStep objects not serving as dependencies to any other steps.
        """

        steps = []
        steps_of_input, step_of_output = defaultdict(list), {}
        for step_info in self.steps_info:
            config = step_info.step_config
            # Creating BasePipelineStep object
            step = self.step_factory(step_info.step_class, config)
            steps.append(step)

            for input_dataset in config.inputs:
                # Multiple steps can use a dataset as input
                steps_of_input[input_dataset].append(step)
            for output_dataset in config.outputs:
                # An output dataset is generated by exactly one step
                # to ensure correct dependency mapping with uniqueness of output dataset names.
                step_of_output[output_dataset] = step

        # Building dependency graphs for step execution scheduling
        prerequisite_steps, step_dependencies = set(), defaultdict(list)
        for input_dataset in steps_of_input:
            if input_dataset in step_of_output:
                step = step_of_output[input_dataset]
                for next_step in steps_of_input[input_dataset]:
                    prerequisite_steps.add(step) # step that acts as a prerequisite for one or more steps
                    step_dependencies[next_step].append(step) # storing step dependency

        # BasePipelineStep objects not serving as dependencies to any other steps
        leaf_steps = [step for step in steps if step not in prerequisite_steps]

        return step_dependencies, leaf_steps

    @typechecked
    def _compute_step_depth(self, step_depths : Dict[BasePipelineStep, int], step: BasePipelineStep) -> int:
        """Helper method to compute and store the depth/dependency level of a BasePipelineStep object
        according to dependencies between the steps. Memoization is used to cache and reuse
        intermediate depth results, which are also needed for allocating different compute targets
        to steps at the same depth.

        Args:
            step_depths (Dict[BasePipelineStep, int]): Memo acting as a mapping between BasePipelineStep object and
                its dependency level.
            step (BasePipelineStep): Base Pipeline Step object which is a node stored in the
                BasePipelineStep object dependency graph.

        Returns:
            int: Depth/Dependency level of the specified BasePipelineStep object node.
        """

        # Checking memo for pre-computed results
        if step in step_depths:
            return step_depths[step]

        prev_steps = self._step_dependencies[step]
        # Calculating and memoing results
        if len(prev_steps) == 0:
            step_depths[step] = 0
        else:
            depth = 0
            # Calculating dependency depth requirement for step execution
            for previous_step in prev_steps:
                depth = max(depth, self._compute_step_depth(step_depths, previous_step))
            step_depths[step] = depth + 1

        return step_depths[step]

    def _create_pipeline_steps(self, compute_targets: List[ComputeTarget]) -> List[PipelineStep]:
        """Helper method to create the list of Python Script Step that are associated with the reusable steps in this
        pipeline. The list of steps resulted by calling this function will be accessible via the steps property.

        Args:
            compute_targets (List[ComputeTarget]): List of compute target(s) to execute the steps on.
                This is a hard requirement from AML SDK.

        Returns:
            List[PipelineStep]: The list of PythonScriptStep instances.
                Using PipelineStep class here to support for type of steps later.
        """
        step_depths = {}

        # Computing dependency levels of each BasePipelineStep object (i.e. node in the dependency graph)
        for last_step in self._leaf_steps:
            # Computing last steps help store and reuse intermediate results (i.e. depths of earlier steps)
            self._compute_step_depth(step_depths, last_step)

        dependency_levels = defaultdict(list)
        # Grouping BasePipelineStep objects by their dependency/depth level
        for step, depth in step_depths.items():
            dependency_levels[depth].append(step)

        # mapping dataset with corresponding PipelineData object for dependency construction
        dependency_data = {}
        for step_info in self.steps_info:
            # We only need to create a PipelineData object for output datasets
            # Reason: the connection between 2 steps can only happen as: output_step1 -> input_step2
            for dataset_name in step_info.step_config.outputs:
                if dataset_name not in dependency_data:
                    dependency_data[dataset_name] = PipelineData(dataset_name)

        compute_target_id = 0
        python_script_steps = []
        # Creating Python Script Steps from BasePipelineStep objects
        for steps in dependency_levels.values():
            for step in steps:
                python_script_step = step.create_step(compute_targets[compute_target_id], dependency_data)
                python_script_steps.append(python_script_step)

                # Round-robin compute target allocation per dependency level
                # Allocation by dependency level is done to execute independent steps in parallel.
                compute_target_id = (compute_target_id + 1) % len(compute_targets)

        return python_script_steps
