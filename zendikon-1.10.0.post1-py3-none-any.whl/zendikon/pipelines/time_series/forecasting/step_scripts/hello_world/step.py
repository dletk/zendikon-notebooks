"""Dummy implementation for a reusable step.
    """

import argparse

from zendikon.aml.tabular_data_step_decorator import TabularDataAmlPythonStepCompatible
from zendikon.aml.types import StepArgument


@TabularDataAmlPythonStepCompatible([StepArgument("time_column", "Column indicate the time stamp", required=True),
                                     StepArgument("ratio", "Ratio value", float, required=True)])
def step_run(data, cli_args: argparse.Namespace = None, run=None):
    """Main function to execute the step.

    Args:
        data (pd.DataFrame): the input data loaded in a pd.DataFrame.
        cli_args (argparse.Namespace, optional): The CLI arguments parsed namespace.
            Defaults to None.
        run (Run): The current AML run instance.
            Defaults to None.
    """

    print(cli_args.ratio)
    print(cli_args.ratio)
    print(run)
    print(data.head(10))

    return data


if __name__ == "__main__":
    step_run()  # pylint: disable=E1120
