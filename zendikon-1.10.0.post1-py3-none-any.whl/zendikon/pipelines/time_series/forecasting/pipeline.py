"""Module containing the reusable pipeline implementation for Time Series Forecasting.
"""

from typing import Dict, Any, List

from azureml.automl.core.forecasting_parameters import ForecastingParameters
from azureml.automl.core.shared.constants import Metric
from azureml.core import ComputeTarget
from azureml.train.automl.constants import Tasks
from typeguard import typechecked

from zendikon.pipelines.automl_pipeline import AutoMLPipeline
from zendikon.pipelines.pipeline import PipelineStepInfo

DEFAULT_METRIC = Metric.NormRMSE


class TimeSeriesForecastingPipeline(AutoMLPipeline):
    """The class represents the reusable pipeline for Time series forecasting problem.
    """

    @typechecked
    def __init__(self, input_datasets: List[str],  # pylint: disable-msg=too-many-arguments
                 forecasting_parameters: ForecastingParameters,
                 compute_targets: List[ComputeTarget],
                 label_column_name: str,
                 automl_config: Dict[str, Any],
                 steps_info: List[PipelineStepInfo],
                 primary_metric: str = DEFAULT_METRIC) -> None:
        """Create an instance of the Time series forecasting reusable pipeline.

        Args:
            input_datasets (List[str]): Names of the input datasets of the pipeline.
            forecasting_parameters (ForecastingParameters): The forecasting parameters for the pipeline.
                Please refer to AML ForecastingParameters documentation.
            compute_targets (List[ComputeTarget]): One or more Compute target instances to run the pipeline.
            label_column_name (str): Name of the column to forecast.
            primary_metric (str, optional): The primary metric to select the best model trained by AutoML.
                Defaults to Metric.NormRMSE.
            automl_config (Dict[str, Any]): The configuration to set up AML AutoML.
                Please refer to AutoMLConfig documentation.
            steps_info (List[PipelineStepInfo]): List of configuration to create steps in the pipeline.
        """
        automl_config["forecasting_parameters"] = forecasting_parameters
        task = Tasks.FORECASTING

        super().__init__(input_datasets, task, primary_metric, compute_targets,
                         label_column_name, automl_config=automl_config, steps_info=steps_info)

    # pylint: disable-msg=arguments-differ
    @classmethod
    def from_default_steps_info(cls, input_datasets: List[str],  # pylint: disable-msg=too-many-arguments
                                forecasting_parameters: ForecastingParameters,
                                compute_targets: List[ComputeTarget],
                                label_column_name: str,
                                automl_config: Dict[str, Any],
                                primary_metric: str = DEFAULT_METRIC) -> "TimeSeriesForecastingPipeline":
        """Create an instance of TimeSeriesForecastingPipeline using the default step infos.
        """
        return cls(input_datasets=input_datasets,
                   forecasting_parameters=forecasting_parameters,
                   compute_targets=compute_targets,
                   label_column_name=label_column_name,
                   automl_config=automl_config,
                   steps_info=cls.default_steps_info,
                   primary_metric=primary_metric)

    @classmethod
    def from_default_automl_config(cls, input_datasets: List[str],  # pylint: disable-msg=too-many-arguments
                                   forecasting_parameters: ForecastingParameters,
                                   compute_targets: List[ComputeTarget],
                                   label_column_name: str,
                                   steps_info: List[PipelineStepInfo],
                                   primary_metric: str = DEFAULT_METRIC) -> "TimeSeriesForecastingPipeline":
        """Create an instance of TimeSeriesForecastingPipeline using the default AutoML config.
        """
        return cls(input_datasets=input_datasets,
                   forecasting_parameters=forecasting_parameters,
                   compute_targets=compute_targets,
                   label_column_name=label_column_name,
                   automl_config=cls.DEFAULT_AUTOML_CONFIG_DICT,
                   steps_info=steps_info,
                   primary_metric=primary_metric)

    @classmethod
    def from_default_settings(cls, input_datasets: List[str],  # pylint: disable-msg=too-many-arguments
                              forecasting_parameters: ForecastingParameters,
                              compute_targets: List[ComputeTarget],
                              label_column_name: str,
                              primary_metric: str = DEFAULT_METRIC) -> "TimeSeriesForecastingPipeline":
        """Create an instance of TimeSeriesForecastingPipeline using the default AutoML Config and step info.
        """
        return cls(input_datasets=input_datasets,
                   forecasting_parameters=forecasting_parameters,
                   compute_targets=compute_targets,
                   label_column_name=label_column_name,
                   automl_config=cls.DEFAULT_AUTOML_CONFIG_DICT,
                   steps_info=cls.default_steps_info,
                   primary_metric=primary_metric)
