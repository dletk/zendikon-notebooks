"""Helper module to train and tests Merlion package time series anomaly detection models.
"""

from typing import Dict, Sequence, Tuple

import pandas as pd
from matplotlib.figure import Figure
from merlion.utils import TimeSeries
from merlion.models.anomaly.base import DetectorBase, DetectorConfig

from merlion.models.anomaly.isolation_forest import IsolationForest, IsolationForestConfig
from merlion.models.anomaly.autoencoder import AutoEncoder, AutoEncoderConfig
from merlion.models.anomaly.deep_point_anomaly_detector import DeepPointAnomalyDetector, DeepPointAnomalyDetectorConfig
from merlion.models.anomaly.dagmm import DAGMM, DAGMMConfig
from merlion.models.anomaly.lstm_ed import LSTMED, LSTMEDConfig
from merlion.models.anomaly.forecast_based.arima import ArimaDetector, ArimaDetectorConfig
from merlion.models.anomaly.forecast_based.prophet import ProphetDetector, ProphetDetectorConfig

from zendikon.aml.utils import print_section_header

DEFAULT_MODEL_CONFIG_PAIRS = (
    (IsolationForest, IsolationForestConfig),
    (AutoEncoder, AutoEncoderConfig),
    (DeepPointAnomalyDetector, DeepPointAnomalyDetectorConfig),
    (DAGMM, DAGMMConfig),
    (LSTMED, LSTMEDConfig),
    (ArimaDetector, ArimaDetectorConfig),
    (ProphetDetector, ProphetDetectorConfig),
)


def train_merlion_models(train_data: pd.DataFrame,
                         model_config_pairs: Sequence[Tuple[DetectorBase, DetectorConfig]] = DEFAULT_MODEL_CONFIG_PAIRS
                         ) -> Dict[str, DetectorBase]:

    trained_models = {}

    print_section_header("TRAINING MERLION MODELS")
    print_section_header("Loading train data")
    train_data = TimeSeries.from_pd(train_data)

    for model_class, config_class in model_config_pairs:
        model_name = model_class.__name__

        print_section_header(f"Started training: {model_name}")
        model: DetectorBase = model_class(config_class())
        model.train(train_data=train_data)

        trained_models[model_name] = model

    return trained_models


def test_merlion_models(test_data: pd.DataFrame,
                        train_data: pd.DataFrame,
                        models: Dict[str, DetectorBase]
                        ) -> Dict[str, Tuple[Figure, pd.DataFrame]]:

    test_results = {}

    print_section_header("TESTING MERLION MODELS")
    test_data = TimeSeries.from_pd(test_data)
    train_data = TimeSeries.from_pd(train_data)

    for model_name, model in models.items():
        print_section_header(f"Testing model: {model_name}")
        test_pred = model.get_anomaly_label(time_series=test_data, time_series_prev=train_data)
        test_pred_df = test_pred.to_pd()

        fig, _ = model.plot_anomaly(test_data, time_series_prev=train_data)

        test_results[model_name] = (fig, test_pred_df)

        print(test_pred_df)

    return test_results
