
"""Module containing the implementation of all steps in the TimeSeries Anomaly Detection pipeline.
"""

import pathlib
from typeguard import typechecked

from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig


class TimeSeriesAnomalyDetectionStep(BasePipelineStep):
    """Base class for all steps that belongs to the TimeSeries Anomaly Detection reusable pipeline.
    """

    STEPS_DIRECTORY = pathlib.Path(__file__).parent.resolve() / "step_scripts"

    @typechecked
    def __init__(self, step_config: StepConfig, source_dir_name: str, script_name: str = None,) -> None:
        """Create a new step that belongs to the TimeSeriesForecasting pipeline. This constructor handles
        resolving the absolute path to the step script if the step script is properly stored within the dedicated
        scripts folder.

        Args:
            step_config (StepConfig): The configuration of this step when creating a pipeline with.
            source_dir_name (str): Name of the directory containing the step scripts.
            script_name (str, optional): Name of the step script file if not following default standard.
                Defaults to None.
        """

        if len(source_dir_name.strip()) == 0:
            raise ValueError("source_dir_name cannot be empty string.")
        source_dir = self.STEPS_DIRECTORY / source_dir_name

        if not source_dir.exists():
            raise ValueError(f"The source_directory does not exist: {source_dir.as_posix()}")

        super().__init__(step_config, script_name=script_name, source_directory=source_dir)


class MerlionModelsTrainingStep(TimeSeriesAnomalyDetectionStep):
    """Class to represent the pipeline step to train multiple models from
    the Merlion package.
    """

    def __init__(self, step_config: StepConfig,
                 source_dir_name="merlion_models_training",
                 script_name: str = None) -> None:
        super().__init__(step_config, source_dir_name, script_name=script_name)
