"""Helper module to train and tests Merlion package time series anomaly detection models.
"""

from typing import Dict, Tuple, Type

import pandas as pd
from matplotlib.figure import Figure
from merlion.utils import TimeSeries
from merlion.models.anomaly.base import DetectorBase, DetectorConfig
from merlion.models.anomaly.isolation_forest import IsolationForest, IsolationForestConfig
from merlion.models.anomaly.autoencoder import AutoEncoder, AutoEncoderConfig
from merlion.models.anomaly.deep_point_anomaly_detector import DeepPointAnomalyDetector, DeepPointAnomalyDetectorConfig
from merlion.models.anomaly.dagmm import DAGMM, DAGMMConfig
from merlion.models.anomaly.lstm_ed import LSTMED, LSTMEDConfig
from merlion.models.anomaly.forecast_based.arima import ArimaDetector, ArimaDetectorConfig
from merlion.models.anomaly.forecast_based.prophet import ProphetDetector, ProphetDetectorConfig
from typeguard import typechecked

from zendikon.aml.utils import print_section_header


DEFAULT_MODEL_CONFIG_PAIRS = {
    IsolationForest: IsolationForestConfig(),
    AutoEncoder: AutoEncoderConfig(),
    DeepPointAnomalyDetector: DeepPointAnomalyDetectorConfig(),
    DAGMM: DAGMMConfig(),
    LSTMED: LSTMEDConfig(),
    ArimaDetector: ArimaDetectorConfig(),
    ProphetDetector: ProphetDetectorConfig(),
}


@typechecked
def train_merlion_models(train_data: pd.DataFrame,
                         model_config_pairs: Dict[Type[DetectorBase], DetectorConfig] = None,
                         ) -> Dict[str, DetectorBase]:
    """Helper function to train a list merlion models using the provided configuration associated with the model class.
    The train data should be a data frame with timeStamp as index. The remaining columns will automatically be
    considered the targets column for anomaly detection.

    Args:
        train_data (pd.DataFrame): The training data, time-stamp index.
        model_config_pairs (Dict[Type[DetectorBase], DetectorConfig], optional): The model class type
            and associated configuration.
            Defaults to None.

    Returns:
        Dict[str, DetectorBase]: Dictionary of trained models, with key is the model name and
            value is the trained model object.
    """

    if model_config_pairs is None:
        model_config_pairs = DEFAULT_MODEL_CONFIG_PAIRS

    trained_models = {}

    print_section_header("TRAINING MERLION MODELS")
    print_section_header("Loading train data")
    train_data = TimeSeries.from_pd(train_data)

    for model_class, config in model_config_pairs.items():
        model_name = model_class.__name__

        print_section_header(f"Started training: {model_name}")
        model: DetectorBase = model_class(config)
        model.train(train_data=train_data)

        trained_models[model_name] = model

    return trained_models


@typechecked
def test_merlion_models(test_data: pd.DataFrame,
                        train_data: pd.DataFrame,
                        models: Dict[str, DetectorBase]
                        ) -> Dict[str, Tuple[Figure, pd.DataFrame]]:
    """Method to test run the trained merlion models on test dataset and return the corresponding prediction.

    Args:
        test_data (pd.DataFrame): The test dataset to run the trained model on.
        train_data (pd.DataFrame): The train dataset used to train these models.
        models (Dict[str, DetectorBase]): Dictionary of trained models, organized by their name.

    Returns:
        Dict[str, Tuple[Figure, pd.DataFrame]]: The prediction on test dataset for different models,
            in matplotlib figure as well as pandas dataframe.
    """
    test_results = {}

    print_section_header("TESTING MERLION MODELS")
    test_data = TimeSeries.from_pd(test_data)
    train_data = TimeSeries.from_pd(train_data)

    for model_name, model in models.items():
        print_section_header(f"Testing model: {model_name}")
        test_pred = model.get_anomaly_label(time_series=test_data, time_series_prev=train_data)
        test_pred_df = test_pred.to_pd()

        fig, _ = model.plot_anomaly(test_data, time_series_prev=train_data)

        test_results[model_name] = (fig, test_pred_df)

        print(test_pred_df)

    return test_results
