"""Subpackage containing the reusable ML pipelines collection for Time Series Anomaly detection.
"""

from zendikon.pipelines.time_series.anomaly_detection.pipeline import TimeSeriesAnomalyDetection
