"""Module contain implementation of the custom AutoMLStep for Zendikon to provide extra functionalities
on top of AML AutoML step.
"""

from pathlib import Path
from typing import Any, Dict, Union
from typing_extensions import Literal

import joblib
from azureml.core import ComputeTarget
from azureml.pipeline.core import PipelineData
from azureml.pipeline.steps import PythonScriptStep
from typeguard import typechecked

from zendikon.pipelines.step.base_step import BasePipelineStep
from zendikon.pipelines.step.step_config import StepConfig


class ZendikonAutoMLStep(BasePipelineStep):
    """Class to represent the implementation of Zendikon AutoML step for AML.
    Because AML does not provide an actual PythonScriptStep for AutoML, but instead a largely different AutoML step,
    it is not following the same standard that we are establishing in Zendikon. Also, we would like to further process
    the AutoML output in the pipeline step. This class allows us to trigger an AutoML run a its child, and return the
    run instance to do further processing.
    """

    AUTOML_CONFIG_FILENAME = "automlconfig_dict.pkl"
    DEFAULT_SOURCE_DIR = Path(__file__).parent.resolve() / "step_scripts" / "automl_step"

    @typechecked
    def __init__(self, automl_config: Dict[str, Any], step_config: StepConfig) -> None:
        """Creating an instance with the ZendikonAutoMLStep.

        Args:
            automl_config (Dict[str, Any]): Configuration to be used for creating an AutoMLConfig instance.
                Please refer to AutoMLConfig documentation for the possible settings.

            step_config (StepConfig, optional): The step configuration for this step instance.
        """
        super().__init__(source_directory=self.DEFAULT_SOURCE_DIR, step_config=step_config)

        if automl_config is None or len(automl_config) == 0:
            raise ValueError(f"automl_config cannot be None or empty, get: {automl_config}")

        self.automl_config = automl_config
        self.automl_config_export_path = self.source_directory / self.AUTOML_CONFIG_FILENAME

    @typechecked
    def create_step(self,
                    compute_target: Union[Literal["local"], ComputeTarget],
                    dependency_data: Dict[str, PipelineData] = None) -> PythonScriptStep:
        """Create the instance of PythonScriptStep that are associated with this reusable step settings.
        This is an overriding to the base class method, because we need to attach the automl configuration
        along with the step in order to create the AutoMLConfig at runtime on AML.

        Args:
            compute_target (Union[Literal["local"], ComputeTarget]): The compute target to submit this step to.
            dependency_data (Dict[str, PipelineData]): Mapping between dataset name and PipelineData object
                for automated dependency construction.

        Returns:
            PythonScriptStep: The instance to be used in the AML pipeline.
        """

        # Exporting automl configuration as a pkl file to be uploaded with the step script
        # so that we can recreate the config on AML.
        _ = joblib.dump(self.automl_config, self.automl_config_export_path)[0]

        return super().create_step(compute_target, dependency_data)

    def clean_automl_config(self):
        """Helper method to clean the exported AutoML config dict.
        This method should be invoked by the calling code to clean after submitting the pipeline.
        """
        self.automl_config_export_path.unlink()
