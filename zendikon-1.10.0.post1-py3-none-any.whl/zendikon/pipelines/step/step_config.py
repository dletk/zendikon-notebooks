"""Module containing the implementation for StepConfig. This class should be used as part of setting up a step
in a pipeline.
"""
import warnings
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union

from azureml.core.runconfig import RunConfiguration
from azureml.core.conda_dependencies import CondaDependencies
from azureml.pipeline.core import PipelineData
from typeguard import typechecked

from zendikon.aml.step_decorator import AbstractAmlPythonStepCompatible
from zendikon.aml.utils import validate_dataset_names
from zendikon.utils.utils import get_repeated_elements
from zendikon._version import VERSION


def _setup_run_config(run_config: Optional[RunConfiguration] = None,
                      conda_dependencies_file: Optional[Union[Path, str]] = None) -> RunConfiguration:
    """Helper method to prepare the RunConfiguration instance for a PythonScriptStep.

    Args:
        run_config (RunConfiguration, optional): The RunConfig instance to modify and add Zendikon dependencies.
            Defaults to None.
        conda_dependencies_file (Union[Path, str], optional): The conda YAML file to create environment for this step.
            Defaults to None.

    Returns:
        RunConfiguration: The modified RunConfig instance with Zendikon dependencies added.
    """

    if run_config is not None and conda_dependencies_file is not None:
        warnings.warn("\x1b[33;20mWARNING: Both run_config and conda_dependencies_file are provided.\x1b[0m "
                      "The conda_dependencies_file will be used to create environment settings for run_config. "
                      "Other settings in the provided run_config will stay the same.")

    run_config = run_config if run_config is not None else RunConfiguration()

    if conda_dependencies_file is not None:
        conda_dependencies = CondaDependencies(conda_dependencies_file)
        run_config.environment.python.conda_dependencies = conda_dependencies
    else:
        conda_dependencies = run_config.environment.python.conda_dependencies

    # Add Zendikon feed to the configuration, if it is already added, this duplication wouldn't cause any error
    conda_dependencies.set_pip_option(
        "--extra-index-url https://pkgs.dev.azure.com/MAIDAP/Zendikon/_packaging/maidap-zendikon/pypi/simple/")
    packages = set(conda_dependencies.pip_packages)

    # if zendikon is already specified, calling add_pip_package will replace the version
    # with what we are specifying here. We do not want that because user might want to use
    # a different version of Zendikon for some compatibility reason.
    missing_zendikon = True
    missing_azureml_defaults = True
    for package in packages:
        if "zendikon" in package:
            missing_zendikon = False
        if "azureml-defaults" in package:
            missing_azureml_defaults = False

    if missing_zendikon:
        # Zendikon not in the list of package
        conda_dependencies.add_pip_package(f"zendikon=={VERSION}")
    if missing_azureml_defaults:
        conda_dependencies.add_pip_package("azureml-defaults")

    return run_config


@dataclass
class StepConfig():
    """Class for controlling settings of a step in Reusable pipeline.

    Attributes:
        name (str): Name to register the step in the pipeline.
        inputs (List[str]): List of registered datasets to be used as inputs for the step.
        outputs (List[str]): List of datasets name to register the outputs of the step.
        arguments (Dict[str, Any]): Dictionary of arguments to set as CLI arguments to the step.
            Example: {"ratio": 0.5, "target_col": "Y"}.
            Defaults to {}.
        run_config: (RunConfiguration): The run configuration that set up the docker environment for the step.
    """

    name: str
    inputs: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    arguments: Dict[str, Any] = field(default_factory=dict)
    conda_dependencies_file: Union[Path, str] = field(default=None)
    run_config: RunConfiguration = field(default=None)

    def __post_init__(self):
        self.__validate_properties_value(self.name, self.inputs, self.outputs,
                                         self.arguments, self.conda_dependencies_file, self.run_config)

        # Checking if any input or output names are getting repeated
        repeated_inputs, repeated_outputs = get_repeated_elements(self.inputs), get_repeated_elements(self.outputs)
        if len(repeated_inputs) > 0:
            raise ValueError("Input dataset names {0} are being repeated in the".format(repeated_inputs) +
                             " StepConfig object name {0}".format(self.name))
        if len(repeated_outputs) > 0:
            raise ValueError("Output dataset names {0} are being repeated in the".format(repeated_inputs) +
                             " StepConfig object name {0}".format(self.name))

        # Check same dataset names for inputs and outputs
        shared_dataset_names = set(self.inputs).intersection(set(self.outputs))
        if len(shared_dataset_names) > 0:
            raise ValueError("Some dataset names {0} are being repeated in the".format(shared_dataset_names) +
                             " input and output lists of the StepConfig object name {0}".format(self.name))

        self.run_config = _setup_run_config(self.run_config, conda_dependencies_file=self.conda_dependencies_file)

    @staticmethod
    @typechecked
    def __validate_properties_value(_name: str,
                                    _inputs: List[str],
                                    _outputs: List[str],
                                    _arguments: Dict[str, Any],
                                    _conda_dependencies_file: Optional[Union[Path, str]],
                                    _run_config: Optional[RunConfiguration]):
        """Helper method to validate the value for all properties after created in the constructor.
        This method use typechecked decorator to quickly and safely validate the type of inputs and prevent
        the need of manual checking. Hence, most of the parameters will not actually be used in the method body.
        Adding _ to the parameter name to indicate this and ensure passing pylint style check.

        Raises:
            TypeError: Raised if any properties does not have the correct type.
        """
        # Checking valid strings for config name and input and output dataset names
        validate_dataset_names(_inputs)
        validate_dataset_names(_outputs)

    @typechecked
    def create_step_parameters(self, dependency_data: Dict[str, PipelineData] = None) \
            -> Dict[str, Union[str, List[Any], RunConfiguration]]:
        """Create an actual parameters dict for being used as inputs to create the actual PythonScriptStep
        from the information stored in this StepConfig instance.

        Args:
            dependency_data (Dict[str, PipelineData]): Mapping between dataset name and PipelineData object
                for automated dependency construction.

        Returns:
            Dict[str, Union[str, List[Any], RunConfiguration]]: The dictionary that can be unpacked as inputs
                for PythonScriptStep.
        """
        input_datasets = ",".join(self.inputs)
        output_datasets = ",".join(self.outputs)

        arguments = sum([
            [f"--{key}", value] for key, value in self.arguments.items()
        ], [])

        arguments = arguments + [
            f"--{AbstractAmlPythonStepCompatible.NAMED_INPUT_DATASETS_ARG_NAME}", input_datasets,
            f"--{AbstractAmlPythonStepCompatible.NAMED_OUTPUT_DATASET_ARG_NAME}", output_datasets
        ]

        step_params = {
            "name": self.name,
            "arguments": arguments,
            "runconfig": self.run_config,
            "inputs": [],
            "outputs": []
        }

        if dependency_data is not None and len(dependency_data) > 0:
            for dataset in self.inputs:
                # Some input dataset might not have associated PipelineData object
                # because that dataset is not from any output.
                if dataset in dependency_data:
                    step_params["inputs"].append(dependency_data[dataset])

        # Every output needs an associated PipelineData object for dependency construction.
        step_params["outputs"] = [dependency_data[dataset] for dataset in self.outputs]

        return step_params
