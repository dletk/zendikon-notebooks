"""Module containing the implementation for the BaseModel class.
The BaseModel class should be the base class for all model trained and created using Zendikon pipeline.
"""


from typing import Dict

from typeguard import typechecked

from zendikon.model.metric.base_metric import Metric


class BaseModel():
    """Base class for managing a model with Zendikon. This model class provide the default implementation
    for features to track, evaluate and manage a model.
    """

    @typechecked
    def __init__(self) -> None:
        """Create a BaseModel instance.
        """

        self.__metrics: Dict[str, Metric] = {}

    @property
    @typechecked
    def metrics(self) -> Dict[str, Metric]:
        """Property for getting the associated metric instances of this model instance.
        Metrics are tracked using distinct name.

        Returns:
            Dict[str, BaseMetric]: Dictionary with key being the metric name and the Metric
                instance as value.
        """
        return self.__metrics.copy()

    @typechecked
    def add_metric(self, metric: Metric, replace_if_exists: bool = False) -> bool:
        """Add a new metric to this model instance.

        Args:
            metric (BaseMetric): The metric to be associated with this model instance.

        Returns:
            bool: True if the metric is added successfully. False otherwise.
        """
        metric_name = metric.name
        if metric_name in self.__metrics:
            if not replace_if_exists:
                raise ValueError("This metric was already added to this model.\n"
                                 "If you want to add this metric, consider set replace_if_exists to True.\n"
                                 f"Current metric being tracked: {self.__metrics[metric_name]}")

            del self.__metrics[metric_name]

        self.__metrics[metric_name] = metric
        return True
