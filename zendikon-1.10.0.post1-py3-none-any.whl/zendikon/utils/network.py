"""
Zendikon utilities for network management.
"""
import socket
import logging


logger = logging.getLogger(__name__)


def check_port(port: int, host: str = "127.0.0.1") -> bool:
    """
    Checks to see if a port is available on a host IP address.

    Args:
        port (int): The port number to check.
        host (str, optional): The host IP address. Defaults to "127.0.0.1".

    Raises:
        err: Unexpected OSError.

    Returns:
        bool: True if the port is not in use on the host, false otherwise.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.bind((host, port))
        sock.close()
    except OSError as err:
        if err.errno != 98:  # address already in use
            logger.error("Unexpected error when checking %s:%d.", host, port)
            raise err
        logger.info("%s:%d is in use.", host, port)
        return False

    logger.info("%s:%d is not in use.", host, port)
    return True
