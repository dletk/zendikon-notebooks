"""
Zendikon utilities for envionment management.
"""
import shutil
import logging

logger = logging.getLogger(__name__)


def check_installed(exec_name: str) -> bool:
    """
    Checks to see if the given executable name is installed in the current environment.

    Args:
        exec_name (str): The name of the executable.

    Returns:
        bool: True if installed in the current environment, false otherwise.
    """
    loc = shutil.which(exec_name)

    if not loc:
        logger.info("%s is not installed in the current environment.", exec_name)
        print(
            f"Failed to find {exec_name} installation. Please make sure you have"
            f" {exec_name} installed."
        )
        return False

    logger.info("%s installation location: %s", exec_name, loc)
    return True
