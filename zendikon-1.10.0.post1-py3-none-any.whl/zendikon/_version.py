"""Reference for the current Zendikon version.
"""

VERSION = "1.10.0r1"
