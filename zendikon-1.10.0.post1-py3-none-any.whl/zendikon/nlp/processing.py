"""
Module Zendikon NLP preprocessing components
"""
import logging
import argparse
from typing import List

import pandas as pd
import spacy
from spacy.tokens import Doc
from azureml.core import Run
from typeguard import typechecked

from zendikon.aml.tabular_data_step_decorator import TabularDataAmlPythonStepCompatible
from zendikon.aml.types import StepArgument

logger = logging.getLogger(__name__)


def _check_spacy_model(model_name):
    """Check if spaCy model is installed and install it if necessarily

    Args:
        model_name (str): spaCy model model
    """

    if not spacy.util.is_package(model_name):
        spacy.cli.download(model_name)


@TabularDataAmlPythonStepCompatible(step_arguments=[
    StepArgument("spacy_model", "Name of the spaCy model", required=True),
    StepArgument("column_name", "Name of the target column in the dataframe", required=True),
])
@typechecked
def tokenize(data: pd.DataFrame, args: argparse.Namespace, _: Run = None) -> List[pd.DataFrame]:
    """
    Tokenize the text in the input dataframe using spaCy

    Args:
        data (pd.DataFrame): Input dataframe
        args (argparse.Namespace): Namespace, should contain a `column_name` property which specifes the target column.
        run (azureml.core.Run, optional): AzureML Run object, if running in AzureML. Defaults to None.

    Returns:
        List[pd.DataFrame]: DataFrame with the `arg.column_name` containing tokenized text
    """

    default_spacy_model = "en_core_web_sm"

    try:
        column_name = args.column_name
    except AttributeError as exc:
        raise ValueError("Specify the `column_name` command line argument") from exc

    if column_name not in data.columns:
        raise ValueError(f"Column {column_name} is not in dataframe")

    if not args.spacy_model:
        logging.info('spacy model is not set, setting default: %s', default_spacy_model)
        args.spacy_model = default_spacy_model

    logging.info('Using spacy model: %s', args.spacy_model)

    _check_spacy_model(args.spacy_model)
    nlp = spacy.load(args.spacy_model)
    tokenizer = nlp.tokenizer

    data[column_name] = data[column_name].apply(tokenizer)

    return [data, ]


@TabularDataAmlPythonStepCompatible(step_arguments=[
    StepArgument("column_name", "Name of the target column in the dataframe", required=True),
])
@typechecked
def remove_stop_words(data: pd.DataFrame, args: argparse.Namespace, _: Run = None) -> List[pd.DataFrame]:
    """
    Remove stop words from the text. This function expects the spaCy's Doc objects. Namelt, each row in the
    input column should contain a spacy.tokens.Doc object

    Args:
        data (pd.DataFrame): List containing the input dataframe
        args (argparse.Namespace): Namespace, should contain a `column_name` property which specifes the target column.
        run (azureml.core.Run, optional): AzureML Run object, if running in AzureML. Defaults to None.

    Returns:
        List[pd.DataFrame]: DataFrame with the `arg.column_name` containing the text without stop words
    """

    def _remove_stop_words(text):
        spaces = [len(tok.whitespace_) > 0 for tok in text]
        tokens, spaces = zip(*[(str(tok), s) for tok, s in zip(text, spaces) if not tok.is_stop])
        doc = Doc(text.vocab, words=tokens, spaces=spaces)

        return doc

    try:
        column_name = args.column_name
    except AttributeError as exc:
        raise ValueError("Specify the `column_name` command line argument") from exc

    if column_name not in data.columns:
        raise ValueError(f"Column {column_name} is not in dataframe")

    if not isinstance(data[column_name][0], Doc):
        raise ValueError(f"Column {column_name} should containt spaCy Doc objects")

    data[column_name] = data[column_name].apply(_remove_stop_words)

    return [data, ]
