"""
NLP package provides common functionality for Natural Language Processing tasks,
such as tokenization and stop words removal
"""
